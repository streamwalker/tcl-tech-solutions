# Signing & notarizing the bridge build

These steps are run once per release by TCL Tech on a macOS build host
with an Apple Developer ID. Dealers do **not** run them — they're
documented here so the dealer-facing archive can advertise "signed by
TCL Tech LLC" honestly.

## Prerequisites

- Apple Developer ID Application certificate installed in the login
  keychain.
- App-specific password for `notarytool` stored in a keychain profile
  named `tcltech-notary`:

  ```
  xcrun notarytool store-credentials tcltech-notary \
    --apple-id "developer@tcltechsolutions.com" \
    --team-id  "ABCDE12345" \
    --password "app-specific-password"
  ```

## Sign

```
IDENTITY="Developer ID Application: TCL Tech Solutions LLC (ABCDE12345)"

codesign --force --options runtime --timestamp \
  --sign "$IDENTITY" dist/urc-rose-bridge

codesign --force --options runtime --timestamp \
  --sign "$IDENTITY" dist/urc-rose-probe

codesign --verify --verbose=2 dist/urc-rose-bridge
codesign --verify --verbose=2 dist/urc-rose-probe
```

## Package

```
VERSION="$(./dist/urc-rose-bridge --version)"
OUT="urc-rose-bridge-macos-arm64-${VERSION}.tar.gz"

( cd dist && tar czf "../$OUT" . )
```

## Notarize

```
xcrun notarytool submit "$OUT" \
  --keychain-profile tcltech-notary \
  --wait
```

A successful submission ends with `status: Accepted`. There is no
separate stapling step for tar.gz archives — the binaries inside carry
their notarization tickets.

## Publish

1. Upload `$OUT` to `https://bridge.tcltechsolutions.com/downloads/`.
2. Sign in to the bridge admin UI → Releases → New release.
3. Paste the version, the public URL, the sha256
   (`shasum -a 256 "$OUT"`), and release notes. Mark it as current.

`update.sh` on every deployed Mac mini will pick up the new version on
its next run.