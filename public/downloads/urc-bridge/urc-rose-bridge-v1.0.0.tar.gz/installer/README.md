# urc-rose-bridge installer

One-shot installer for the Mac mini bridge. Run as root on a fresh Mac
mini (Apple Silicon).

## Quickstart

```
# Download installer + bridge archive into the same directory:
#   urc-rose-bridge-installer.tar.gz         (this kit)
#   urc-rose-bridge-macos-arm64-X.Y.Z.tar.gz (the bridge binary)

tar xzf urc-rose-bridge-installer.tar.gz
cd installer
xattr -dr com.apple.quarantine .
sudo ./install.sh
```

After install, edit `/usr/local/urc-rose-bridge/.env` to set `ROSE_HOST`
and restart:

```
sudo launchctl kickstart -k system/com.tcltech.urc-rose-bridge
```

## Files

- `install.sh` — installs binary, registers launchd daemon, health-checks.
- `update.sh` — pulls latest release manifest, verifies sha256, swaps the
  binary, restarts the daemon.
- `uninstall.sh` — stops the daemon and removes `/usr/local/urc-rose-bridge`.
- `com.tcltech.urc-rose-bridge.plist` — launchd descriptor copied to
  `/Library/LaunchDaemons/` by the installer.
- `SIGNING.md` — codesign + notarize procedure for TCL Tech builds.

## Logs

- `/usr/local/var/log/urc-rose-bridge.out.log`
- `/usr/local/var/log/urc-rose-bridge.err.log`

## Auto-update

`update.sh` polls
`https://bridge.tcltechsolutions.com/api/public/releases/latest` and
performs a sha256-verified, in-place swap. Schedule it weekly with a
launchd calendar job or run it manually after a release announcement.