// Unit + integration tests for the universal translator core.
// Run: npm test   (node --import tsx --test)

import { test } from "node:test";
import assert from "node:assert/strict";

import { TranslatorRouter } from "../src/universal/router.js";
import { buildTranslator } from "../src/universal/translator.js";
import { MockAdapter, demoMockAdapter } from "../src/universal/adapters/mock.js";
import { Control4Adapter } from "../src/universal/adapters/control4.js";
import { UrcAdapter } from "../src/universal/adapters/urc.js";
import { JoshAdapter } from "../src/universal/adapters/josh.js";
import { capabilitySupportsAction, diffState, TranslatorError, type CanonicalState } from "../src/universal/model.js";
import { normalizeSource, clampLevel, scaleLevel, ROSE_SOURCE_TO_CANONICAL, CANONICAL_TO_ROSE_SOURCE } from "../src/universal/mappings.js";
import { isController } from "../src/universal/adapter.js";

// ---- model + mappings -------------------------------------------------------

test("capability/action validation", () => {
  assert.equal(capabilitySupportsAction("power", "set"), true);
  assert.equal(capabilitySupportsAction("power", "toggle"), true);
  assert.equal(capabilitySupportsAction("power", "fly"), false);
  assert.equal(capabilitySupportsAction("transport", "next"), true);
});

test("source normalization + rose round-trip", () => {
  assert.equal(normalizeSource("Optical In"), "optical");
  assert.equal(normalizeSource("HDMI ARC"), "earc");
  assert.equal(normalizeSource("totally-unknown"), "totally-unknown"); // preserved, not dropped
  assert.equal(ROSE_SOURCE_TO_CANONICAL.OPTICAL, "optical");
  assert.equal(CANONICAL_TO_ROSE_SOURCE.optical, "OPTICAL");
});

test("level helpers clamp + scale", () => {
  assert.equal(clampLevel(150), 100);
  assert.equal(clampLevel(-5), 0);
  assert.equal(clampLevel(33.6), 34);
  assert.equal(scaleLevel(50, 255), 128);
});

test("diffState reports changed fields", () => {
  const a: CanonicalState = { entityId: "x", reachable: true, power: "off" };
  const b: CanonicalState = { entityId: "x", reachable: true, power: "on" };
  assert.deepEqual(diffState(a, b), ["power"]);
  assert.deepEqual(diffState(b, b), []);
  assert.ok(diffState(null, b).includes("power"));
});

// ---- router dispatch + guards ----------------------------------------------

test("router dispatch mutates device state; enforces capability + entity guards", async () => {
  const router = new TranslatorRouter({ defaultPollIntervalMs: 60_000 });
  router.register(demoMockAdapter());
  await router.start();
  try {
    const light = "control4:light:living-room-lights";
    await router.dispatch({ entityId: light, capability: "power", action: "set", args: { state: "on" } });
    assert.equal((await router.readFresh(light)).power, "on");

    await assert.rejects(
      () => router.dispatch({ entityId: light, capability: "climate", action: "set", args: { setpoint: 20 } }),
      (e: unknown) => e instanceof TranslatorError && e.code === "capability_unsupported",
    );
    await assert.rejects(
      () => router.dispatch({ entityId: "does:not:exist", capability: "power", action: "set" }),
      (e: unknown) => e instanceof TranslatorError && e.code === "entity_not_found",
    );
  } finally {
    await router.stop();
  }
});

// ---- THE headline: a Josh voice intent drives a Control4-only device --------

test("Josh utterance -> canonical -> Control4 light (cross-ecosystem)", async () => {
  const router = buildTranslator({ mockDemo: true, controllers: ["josh", "urc", "control4"], pollIntervalMs: 60_000 });
  await router.start();
  try {
    const josh = router.adapterList().find((a) => a.ecosystem === "josh");
    assert.ok(josh && isController(josh));

    const cmds = await josh.controller.translateInbound({ utterance: "turn on the living room lights" });
    assert.equal(cmds.length, 1);
    assert.equal(cmds[0].entityId, "control4:light:living-room-lights");
    assert.equal(cmds[0].capability, "power");
    assert.equal(cmds[0].source?.ecosystem, "josh");

    for (const c of cmds) await router.dispatch(c);
    assert.equal((await router.readFresh("control4:light:living-room-lights")).power, "on");
  } finally {
    await router.stop();
  }
});

test("Josh structured intent sets the Josh-owned thermostat", async () => {
  const router = buildTranslator({ mockDemo: true, controllers: ["josh"], pollIntervalMs: 60_000 });
  await router.start();
  try {
    const josh = router.adapterList().find((a) => a.ecosystem === "josh")!;
    const cmds = await josh.controller!.translateInbound({ intent: "set_temperature", room: "Hallway", value: 23 });
    assert.equal(cmds.length, 1);
    assert.equal(cmds[0].entityId, "josh:thermostat:thermostat");
    for (const c of cmds) await router.dispatch(c);
    assert.equal((await router.readFresh("josh:thermostat:thermostat")).climate?.setpoint, 23);
  } finally {
    await router.stop();
  }
});

// ---- URC controller translation --------------------------------------------

test("URC IP-driver functions translate to canonical", () => {
  const urc = new UrcAdapter();
  const ent = "urc:media_player:patio-speakers";
  const set = urc.controller.translateInbound({ function: "VolumeSet", value: 42, entityId: ent }) as any;
  assert.equal(set[0].capability, "volume");
  assert.equal(set[0].action, "set");
  assert.equal(set[0].args.level, 42);

  const src = urc.controller.translateInbound({ function: "Input2", entityId: ent }) as any;
  assert.equal(src[0].capability, "source");
  assert.equal(src[0].args.source, "optical"); // URC input 2 -> optical (default map)

  const pwr = urc.controller.translateInbound({ function: "PowerToggle", entityId: ent }) as any;
  assert.equal(pwr[0].action, "toggle");
});

test("URC renderState produces flat parse-data keys", () => {
  const urc = new UrcAdapter();
  const rendered = urc.controller.renderState!(
    { id: "x", type: "media_player", name: "Amp", ecosystem: "urc", nativeId: "1", capabilities: ["power", "volume", "source"] },
    { entityId: "x", reachable: true, power: "on", source: "optical", volume: { level: 30, muted: false } },
  ) as Record<string, unknown>;
  assert.equal(rendered.POWER, "ON");
  assert.equal(rendered.SOURCE, "OPTICAL");
  assert.equal(rendered.VOLUME, 30);
  assert.equal(rendered.MUTE, 0);
});

// ---- Control4 controller translation ---------------------------------------

test("Control4 Director verbs map to canonical", () => {
  const c4 = new Control4Adapter();
  const on = c4.controller.translateInbound({ entityId: "x", command: "ON" }) as any;
  assert.equal(on[0].capability, "power");
  assert.equal(on[0].args.state, "on");

  const lvl = c4.controller.translateInbound({ entityId: "x", command: "SET_LEVEL", level: 60 }) as any;
  assert.equal(lvl[0].capability, "brightness");
  assert.equal(lvl[0].args.level, 60);

  // Canonical relay passthrough also accepted.
  const relay = c4.controller.translateInbound({ entityId: "x", capability: "lock", action: "set", args: { state: "locked" } }) as any;
  assert.equal(relay[0].capability, "lock");
});

// ---- a "trapped" device becomes reachable by every controller --------------

test("the same Control4 light is reachable from URC, Josh, and a direct command", async () => {
  const router = buildTranslator({ mockDemo: true, controllers: ["josh", "urc", "control4"], pollIntervalMs: 60_000 });
  await router.start();
  try {
    const light = "control4:light:living-room-lights";
    const urc = router.adapterList().find((a) => a.ecosystem === "urc")!;
    const josh = router.adapterList().find((a) => a.ecosystem === "josh")!;

    // URC keypad -> on
    for (const c of await urc.controller!.translateInbound({ function: "PowerOn", entityId: light })) await router.dispatch(c);
    assert.equal((await router.readFresh(light)).power, "on");

    // Josh voice -> off
    for (const c of await josh.controller!.translateInbound({ utterance: "turn off the living room lights" })) await router.dispatch(c);
    assert.equal((await router.readFresh(light)).power, "off");

    // Direct canonical -> brightness (implies on)
    await router.dispatch({ entityId: light, capability: "brightness", action: "set", args: { level: 75 } });
    const s = await router.readFresh(light);
    assert.equal(s.brightness, 75);
    assert.equal(s.power, "on");
  } finally {
    await router.stop();
  }
});

// ---- state events fire on change -------------------------------------------

test("router emits a state event when a device changes", async () => {
  const router = new TranslatorRouter({ defaultPollIntervalMs: 60_000 });
  router.register(
    new MockAdapter({ entities: [{ slug: "lamp", type: "light", name: "Lamp", capabilities: ["power"] }] }),
  );
  const events: string[] = [];
  router.onEvent((e) => events.push(`${e.entityId}:${e.changed.join(",")}`));
  await router.start();
  try {
    await router.dispatch({ entityId: "mock:light:lamp", capability: "power", action: "set", args: { state: "on" } });
    // allow the post-dispatch refresh microtask to land
    await new Promise((r) => setTimeout(r, 20));
    assert.ok(events.some((e) => e.startsWith("mock:light:lamp") && e.includes("power")), `events=${events.join("|")}`);
  } finally {
    await router.stop();
  }
});
