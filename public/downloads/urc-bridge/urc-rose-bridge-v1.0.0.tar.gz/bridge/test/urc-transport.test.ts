// Live integration test for the concrete TCP transport: a real socket against
// an in-process fake URC processor that speaks token-secured ASCII.

import net from "node:net";
import { test } from "node:test";
import assert from "node:assert/strict";

import { createUrcTcpTransport, defaultHandshake } from "../src/universal/adapters/urc-transport.js";
import { UrcAdapter } from "../src/universal/adapters/urc.js";
import { TranslatorRouter } from "../src/universal/router.js";
import type { CanonicalEntity } from "../src/universal/model.js";

interface FakeUrc {
  port: number;
  received: string[];
  authAttempts: string[];
  close: () => Promise<void>;
}

function startFakeUrc(opts: { token: string } = { token: "secret" }): Promise<FakeUrc> {
  const st = { power: "OFF", vol: 20, input: 2, muted: false, play: false };
  const received: string[] = [];
  const authAttempts: string[] = [];

  const server = net.createServer((sock) => {
    sock.setEncoding("utf8");
    let buf = "";
    sock.on("data", (d: string) => {
      buf += d;
      let i: number;
      while ((i = buf.indexOf("\r")) >= 0) {
        const frame = buf.slice(0, i).trim();
        buf = buf.slice(i + 1);
        if (frame) handle(frame, sock);
      }
    });
    sock.on("error", () => undefined);
  });

  function handle(f: string, sock: net.Socket) {
    if (f.startsWith("AUTH ")) {
      const tok = f.slice(5);
      authAttempts.push(tok);
      sock.write(tok === opts.token ? "OK\r" : "NACK\r");
      return;
    }
    if (f === "STATUS?") {
      sock.write([`PWR=${st.power}`, `VOL=${st.vol}`, `MUTE=${st.muted ? 1 : 0}`, `INPUT=${st.input}`, `PLAY=${st.play ? 1 : 0}`].join("\r") + "\r");
      return;
    }
    received.push(f);
    if (f === "PWR ON") st.power = "ON";
    else if (f === "PWR OFF") st.power = "OFF";
    else if (f === "VOL UP") st.vol += 2;
    else if (f === "VOL DOWN") st.vol -= 2;
    else if (f.startsWith("VOL ")) st.vol = Number(f.slice(4));
    else if (f === "MUTE") st.muted = !st.muted;
    else if (f.startsWith("INPUT ")) st.input = Number(f.slice(6));
    else if (f === "PLAY") st.play = true;
    else if (f === "PAUSE" || f === "STOP") st.play = false;
  }

  return new Promise((resolve) => {
    server.listen(0, "127.0.0.1", () => {
      const addr = server.address();
      const port = typeof addr === "object" && addr ? addr.port : 0;
      resolve({ port, received, authAttempts, close: () => new Promise<void>((r) => server.close(() => r())) });
    });
  });
}

const zone: CanonicalEntity = {
  id: "urc:media_player:zone1",
  type: "media_player",
  name: "Listening Zone (URC-only)",
  ecosystem: "urc",
  nativeId: "1",
  capabilities: ["power", "volume", "source", "transport"],
};

test("TCP transport: token handshake + commands + two-way status over a real socket", async () => {
  const srv = await startFakeUrc({ token: "secret" });
  const transport = createUrcTcpTransport({ host: "127.0.0.1", port: srv.port, token: "secret", terminator: "\r", quietMs: 30, queryTimeoutMs: 800 });
  const urc = new UrcAdapter({ transport, entities: [zone] });
  const router = new TranslatorRouter({ defaultPollIntervalMs: 60_000 });
  router.register(urc);
  await router.start();
  try {
    await router.dispatch({ entityId: zone.id, capability: "power", action: "set", args: { state: "on" } });
    await router.dispatch({ entityId: zone.id, capability: "source", action: "set", args: { source: "optical" } });
    await router.dispatch({ entityId: zone.id, capability: "volume", action: "set", args: { level: 55 } });
    await new Promise((r) => setTimeout(r, 80)); // let the socket flush

    assert.deepEqual(srv.authAttempts, ["secret"], "presented the token once");
    assert.deepEqual(srv.received, ["PWR ON", "INPUT 2", "VOL 55"]);

    const s = await router.readFresh(zone.id);
    assert.equal(s.power, "on");
    assert.equal(s.source, "optical");
    assert.equal(s.volume?.level, 55);
    assert.equal(s.reachable, true);
  } finally {
    await router.stop();
    await transport.close();
    await srv.close();
  }
});

test("TCP transport: a wrong token is rejected by the secured handshake", async () => {
  const srv = await startFakeUrc({ token: "secret" });
  const transport = createUrcTcpTransport({ host: "127.0.0.1", port: srv.port, token: "WRONG", terminator: "\r", quietMs: 30, queryTimeoutMs: 800, handshake: defaultHandshake });
  try {
    await assert.rejects(() => transport.connect(), /auth rejected/i);
  } finally {
    await transport.close();
    await srv.close();
  }
});
