// Tests for the URC token-secured ASCII path: codec (encode/parse) + the
// transport-backed device host, including an end-to-end router dispatch onto a
// simulated URC-owned device.

import { test } from "node:test";
import assert from "node:assert/strict";

import {
  encodeCommand,
  parseResponse,
  defaultParseRules,
  DEFAULT_URC_COMMAND_MAP,
  DEFAULT_INPUT_INDEX,
  type UrcAsciiTransport,
} from "../src/universal/adapters/urc-ascii.js";
import { UrcAdapter } from "../src/universal/adapters/urc.js";
import { TranslatorRouter } from "../src/universal/router.js";
import type { CanonicalCommand, CanonicalEntity } from "../src/universal/model.js";

const cmd = (capability: string, action: string, args?: Record<string, unknown>): CanonicalCommand =>
  ({ entityId: "x", capability: capability as CanonicalCommand["capability"], action, args });

// ---- codec: canonical -> ASCII ---------------------------------------------

test("encodeCommand maps canonical commands to URC ASCII frames", () => {
  const m = DEFAULT_URC_COMMAND_MAP, ix = DEFAULT_INPUT_INDEX;
  assert.equal(encodeCommand(cmd("power", "set", { state: "on" }), m, ix), "PWR ON");
  assert.equal(encodeCommand(cmd("power", "set", { state: "off" }), m, ix), "PWR OFF");
  assert.equal(encodeCommand(cmd("power", "toggle"), m, ix), "PWR TOGGLE");
  assert.equal(encodeCommand(cmd("volume", "set", { level: 42 }), m, ix), "VOL 42");
  assert.equal(encodeCommand(cmd("volume", "step", { delta: 3 }), m, ix), "VOL UP");
  assert.equal(encodeCommand(cmd("volume", "step", { delta: -3 }), m, ix), "VOL DOWN");
  assert.equal(encodeCommand(cmd("volume", "mute"), m, ix), "MUTE");
  assert.equal(encodeCommand(cmd("source", "set", { source: "optical" }), m, ix), "INPUT 2");
  assert.equal(encodeCommand(cmd("transport", "play"), m, ix), "PLAY");
  // unmappable -> null (host reports unsupported rather than guessing)
  assert.equal(encodeCommand(cmd("source", "set", { source: "nonexistent" }), m, ix), null);
  assert.equal(encodeCommand(cmd("climate", "set", { setpoint: 20 }), m, ix), null);
});

// ---- codec: ASCII -> canonical state ---------------------------------------

test("parseResponse maps URC ASCII status into canonical state", () => {
  const rules = defaultParseRules(DEFAULT_INPUT_INDEX);
  const s = parseResponse("PWR=ON\rVOL=35\rMUTE=1\rINPUT=3\rPLAY=1", rules, "x");
  assert.equal(s.power, "on");
  assert.equal(s.volume?.level, 35);
  assert.equal(s.volume?.muted, true);
  assert.equal(s.source, "earc"); // INPUT 3 -> earc
  assert.equal(s.transport?.playing, true);
  assert.equal(s.reachable, true);
});

// ---- a simulated token-secured URC device over ASCII -----------------------

class FakeUrcDevice implements UrcAsciiTransport {
  connected = false;
  sent: string[] = [];
  private power = "OFF";
  private vol = 20;
  private muted = false;
  private input = 2;
  private play = false;
  constructor(private token: string) {}
  async connect() {
    if (this.token !== "secret") throw new Error("unauthorized: bad token");
    this.connected = true;
  }
  async send(frame: string) {
    const f = frame.trim();
    this.sent.push(f);
    if (f === "PWR ON") this.power = "ON";
    else if (f === "PWR OFF") this.power = "OFF";
    else if (f === "PWR TOGGLE") this.power = this.power === "ON" ? "OFF" : "ON";
    else if (f === "VOL UP") this.vol += 2;
    else if (f === "VOL DOWN") this.vol -= 2;
    else if (f.startsWith("VOL ")) this.vol = Number(f.slice(4));
    else if (f === "MUTE") this.muted = !this.muted;
    else if (f.startsWith("INPUT ")) this.input = Number(f.slice(6));
    else if (f === "PLAY") this.play = true;
    else if (f === "PAUSE" || f === "STOP") this.play = false;
  }
  async query() {
    return [`PWR=${this.power}`, `VOL=${this.vol}`, `MUTE=${this.muted ? 1 : 0}`, `INPUT=${this.input}`, `PLAY=${this.play ? 1 : 0}`].join("\r");
  }
  async close() {
    this.connected = false;
  }
}

const zone: CanonicalEntity = {
  id: "urc:media_player:zone1",
  type: "media_player",
  name: "Listening Zone (URC-only)",
  ecosystem: "urc",
  nativeId: "1",
  capabilities: ["power", "volume", "source", "transport"],
};

test("router dispatches onto a URC-only device over the secured ASCII transport", async () => {
  const transport = new FakeUrcDevice("secret");
  const urc = new UrcAdapter({ transport, entities: [zone] });
  const router = new TranslatorRouter({ defaultPollIntervalMs: 60_000 });
  router.register(urc);
  await router.start();
  try {
    // A command originating elsewhere lands on the URC device as ASCII.
    await router.dispatch({ entityId: zone.id, capability: "power", action: "set", args: { state: "on" } });
    await router.dispatch({ entityId: zone.id, capability: "source", action: "set", args: { source: "optical" } });
    await router.dispatch({ entityId: zone.id, capability: "volume", action: "set", args: { level: 55 } });

    assert.ok(transport.connected, "transport performed the token handshake");
    assert.deepEqual(transport.sent, ["PWR ON", "INPUT 2", "VOL 55"]);

    // Two-way: status query parses back into canonical state.
    const s = await router.readFresh(zone.id);
    assert.equal(s.power, "on");
    assert.equal(s.source, "optical");
    assert.equal(s.volume?.level, 55);
  } finally {
    await router.stop();
  }
});

test("unmapped command is reported, not silently sent", async () => {
  const transport = new FakeUrcDevice("secret");
  const urc = new UrcAdapter({ transport, entities: [{ ...zone, capabilities: ["climate"] }] });
  const router = new TranslatorRouter({ defaultPollIntervalMs: 60_000 });
  router.register(urc);
  await router.start();
  try {
    await assert.rejects(
      () => router.dispatch({ entityId: zone.id, capability: "climate", action: "set", args: { setpoint: 21 } }),
      /no command mapping/,
    );
  } finally {
    await router.stop();
  }
});

test("bad token fails the handshake and surfaces as adapter_unreachable", async () => {
  const transport = new FakeUrcDevice("WRONG");
  const urc = new UrcAdapter({ transport, entities: [zone] });
  const router = new TranslatorRouter({ defaultPollIntervalMs: 60_000 });
  router.register(urc);
  await router.start();
  try {
    await assert.rejects(
      () => router.dispatch({ entityId: zone.id, capability: "power", action: "set", args: { state: "on" } }),
      (e: unknown) => e instanceof Error && /unreachable|token/i.test((e as Error).message),
    );
  } finally {
    await router.stop();
  }
});
