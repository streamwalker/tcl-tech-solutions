// HTTP-surface tests using Fastify's inject (no real sockets / no hardware).
// Covers /v2 universal routes and the /v1 Rose-compat shim end-to-end.

import { test } from "node:test";
import assert from "node:assert/strict";
import Fastify, { type FastifyInstance } from "fastify";

import { buildTranslator } from "../src/universal/translator.js";
import { MockAdapter } from "../src/universal/adapters/mock.js";
import { registerUniversalRoutes } from "../src/universal/api.js";
import { registerV1Shim } from "../src/universal/v1-shim.js";
import { loadConfig } from "../src/config.js";
import type { TranslatorRouter } from "../src/universal/router.js";

async function buildApp(): Promise<{ app: FastifyInstance; router: TranslatorRouter }> {
  // No live Rose; controllers for all three ecosystems; high poll interval so
  // background polling does not interfere with assertions.
  const router = buildTranslator({ mockDemo: true, controllers: ["josh", "urc", "control4"], pollIntervalMs: 60_000 });
  // Stand in a Rose-ecosystem device so the /v1 shim has something to bind to.
  router.register(
    new MockAdapter({
      id: "mock-rose",
      ecosystem: "rose",
      entities: [
        {
          slug: "rose",
          type: "media_player",
          name: "RS520 (mock)",
          capabilities: ["power", "volume", "source"],
          initial: { power: "off", source: "optical", volume: { level: 20, muted: false } },
        },
      ],
    }),
  );
  await router.start();

  const app = Fastify({ logger: false });
  await registerUniversalRoutes(app, { router, startedAt: Date.now() });
  registerV1Shim(app, { router, config: loadConfig(), startedAt: Date.now() });
  await app.ready();
  return { app, router };
}

test("/v2/entities lists devices across ecosystems", async () => {
  const { app, router } = await buildApp();
  try {
    const res = await app.inject({ method: "GET", url: "/v2/entities" });
    assert.equal(res.statusCode, 200);
    const body = res.json();
    assert.ok(body.count >= 5);
    const ids: string[] = body.entities.map((e: { id: string }) => e.id);
    assert.ok(ids.includes("control4:light:living-room-lights"));
    assert.ok(ids.includes("josh:thermostat:thermostat"));
    assert.ok(ids.includes("rose:media_player:rose"));
  } finally {
    await app.close();
    await router.stop();
  }
});

test("POST /v2/ingress/josh translates an utterance and dispatches it", async () => {
  const { app, router } = await buildApp();
  try {
    const res = await app.inject({
      method: "POST",
      url: "/v2/ingress/josh",
      payload: { utterance: "turn on the living room lights" },
    });
    assert.equal(res.statusCode, 200);
    const body = res.json();
    assert.equal(body.ok, true);
    assert.equal(body.translated, 1);
    assert.equal(body.results[0].ok, true);

    const state = await app.inject({ method: "GET", url: "/v2/entities/control4:light:living-room-lights/state?fresh=1" });
    assert.equal(state.json().state.power, "on");
  } finally {
    await app.close();
    await router.stop();
  }
});

test("POST /v2/command validates required fields", async () => {
  const { app, router } = await buildApp();
  try {
    const res = await app.inject({ method: "POST", url: "/v2/command", payload: { entityId: "x" } });
    assert.equal(res.statusCode, 400);
    assert.equal(res.json().error, "bad_args");
  } finally {
    await app.close();
    await router.stop();
  }
});

test("unsupported capability returns 400 via /v2/command", async () => {
  const { app, router } = await buildApp();
  try {
    const res = await app.inject({
      method: "POST",
      url: "/v2/command",
      payload: { entityId: "control4:lock:front-door", capability: "volume", action: "set", args: { level: 10 } },
    });
    assert.equal(res.statusCode, 400);
    assert.equal(res.json().error, "capability_unsupported");
  } finally {
    await app.close();
    await router.stop();
  }
});

test("/v1 shim round-trips against the Rose-ecosystem device", async () => {
  const { app, router } = await buildApp();
  try {
    let state = (await app.inject({ method: "GET", url: "/v1/state" })).json();
    assert.equal(state.ok, true);
    assert.equal(state.source, "OPTICAL"); // canonical 'optical' re-presented as Rose enum
    assert.equal(state.power, "off");

    const pwr = await app.inject({ method: "POST", url: "/v1/power", payload: { state: "on" } });
    assert.equal(pwr.statusCode, 200);

    const src = await app.inject({ method: "POST", url: "/v1/source", payload: { input: "USB" } });
    assert.equal(src.statusCode, 200);

    state = (await app.inject({ method: "GET", url: "/v1/state" })).json();
    assert.equal(state.power, "on");
    assert.equal(state.source, "USB");

    const transport = await app.inject({ method: "POST", url: "/v1/transport", payload: { cmd: "play" } });
    assert.equal(transport.statusCode, 501);
  } finally {
    await app.close();
    await router.stop();
  }
});

test("GET /v2/health reports adapters and reachable entities", async () => {
  const { app, router } = await buildApp();
  try {
    const res = await app.inject({ method: "GET", url: "/v2/health" });
    assert.equal(res.statusCode, 200);
    const body = res.json();
    assert.equal(body.ok, true);
    assert.ok(body.entities >= 5);
    assert.ok(body.adapters.some((a: string) => a.startsWith("josh")));
  } finally {
    await app.close();
    await router.stop();
  }
});
