// Minimal level-gated logger. Avoids a runtime dep so the container stays small.
// Bridge and probe both use this.

export type LogLevel = "error" | "warn" | "info" | "debug";

const LEVELS: Record<LogLevel, number> = { error: 0, warn: 1, info: 2, debug: 3 };

function envLevel(): LogLevel {
  const raw = (process.env.LOG_LEVEL || "info").toLowerCase();
  return (raw in LEVELS ? raw : "info") as LogLevel;
}

let activeLevel: LogLevel = envLevel();

export function setLogLevel(level: LogLevel): void {
  activeLevel = level;
}

function emit(level: LogLevel, msg: string, extra?: unknown): void {
  if (LEVELS[level] > LEVELS[activeLevel]) return;
  const stamp = new Date().toISOString();
  const tag = level.toUpperCase().padEnd(5);
  if (extra !== undefined) {
    const payload = typeof extra === "string" ? extra : JSON.stringify(extra);
    console.log(`${stamp} ${tag} ${msg} ${payload}`);
  } else {
    console.log(`${stamp} ${tag} ${msg}`);
  }
}

export const log = {
  error: (msg: string, extra?: unknown) => emit("error", msg, extra),
  warn: (msg: string, extra?: unknown) => emit("warn", msg, extra),
  info: (msg: string, extra?: unknown) => emit("info", msg, extra),
  debug: (msg: string, extra?: unknown) => emit("debug", msg, extra),
};
