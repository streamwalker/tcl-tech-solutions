// =============================================================================
// Universal /v2 HTTP surface — the protocol-neutral control plane.
// =============================================================================
//
// Every ecosystem talks to the translator through these routes:
//   GET  /v2/entities                  discover everything reachable, any vendor
//   GET  /v2/entities/:id/state        normalized read-back (two-way feedback)
//   POST /v2/command                   issue a canonical command directly
//   POST /v2/ingress/:ecosystem        submit a NATIVE payload; the matching
//                                      adapter translates it to canonical first
//   GET  /v2/entities/:id/render/:eco  canonical state rendered into a vendor's
//                                      native feedback shape
//   GET  /v2/events                    SSE stream of state changes
//
// The /v2/command + /v2/ingress split is the whole product: a Josh utterance
// hits /v2/ingress/josh, becomes canonical, and is dispatched to (say) a
// Control4 device — none of which Josh or Control4 had to know about.

import type { FastifyInstance } from "fastify";
import { isController, type EcosystemAdapter } from "./adapter.js";
import { TranslatorRouter } from "./router.js";
import { TranslatorError, type CanonicalCommand, type EcosystemId, type EntityType } from "./model.js";
import { ECOSYSTEM_LABELS } from "./model.js";
import { log } from "../logger.js";

export interface UniversalDeps {
  router: TranslatorRouter;
  startedAt: number;
}

function controllerFor(router: TranslatorRouter, ecosystem: string): (EcosystemAdapter & { controller: NonNullable<EcosystemAdapter["controller"]> }) | null {
  for (const a of router.adapterList()) {
    if (a.ecosystem === ecosystem && isController(a)) return a;
  }
  return null;
}

function fail(reply: import("fastify").FastifyReply, err: unknown) {
  if (err instanceof TranslatorError) return reply.code(err.httpStatus).send(err.toJSON());
  log.warn("v2 unexpected error", { message: (err as Error).message });
  return reply.code(500).send({ ok: false, error: "internal", message: (err as Error).message });
}

export async function registerUniversalRoutes(app: FastifyInstance, deps: UniversalDeps): Promise<void> {
  const { router, startedAt } = deps;

  // ---- root + health --------------------------------------------------------
  app.get("/v2", async (_req, reply) =>
    reply.send({
      service: "universal-translator",
      version: "0.2.0",
      ecosystems: router.adapterList().map((a) => ({
        ecosystem: a.ecosystem,
        id: a.id,
        controller: isController(a),
        deviceHost: a.device !== undefined,
      })),
      routes: [
        "GET  /v2/entities",
        "GET  /v2/entities/:id",
        "GET  /v2/entities/:id/state?fresh=1",
        "POST /v2/command",
        "POST /v2/ingress/:ecosystem",
        "GET  /v2/entities/:id/render/:ecosystem",
        "GET  /v2/events  (SSE)",
      ],
    }),
  );

  app.get("/v2/health", async (_req, reply) => {
    const entities = router.registry.all();
    const reachable = entities.filter((r) => router.getState(r.entity.id)?.reachable).length;
    return reply.send({
      ok: true,
      uptimeSec: Math.floor((Date.now() - startedAt) / 1000),
      adapters: router.adapterList().map((a) => `${a.ecosystem}:${a.id}`),
      entities: entities.length,
      reachable,
    });
  });

  // ---- discovery ------------------------------------------------------------
  app.get<{ Querystring: { ecosystem?: string; type?: string; room?: string } }>(
    "/v2/entities",
    async (req, reply) => {
      const { ecosystem, type, room } = req.query;
      const entities = router.registry.list({
        ecosystem: ecosystem as EcosystemId | undefined,
        type: type as EntityType | undefined,
        room,
      });
      return reply.send({
        ok: true,
        count: entities.length,
        entities: entities.map((e) => ({ ...e, state: router.getState(e.id) })),
      });
    },
  );

  app.get<{ Params: { id: string } }>("/v2/entities/:id", async (req, reply) => {
    const reg = router.registry.get(req.params.id);
    if (!reg) return reply.code(404).send({ ok: false, error: "entity_not_found" });
    return reply.send({ ok: true, entity: reg.entity, state: router.getState(req.params.id) });
  });

  app.get<{ Params: { id: string }; Querystring: { fresh?: string } }>(
    "/v2/entities/:id/state",
    async (req, reply) => {
      try {
        const state =
          req.query.fresh === "1" || req.query.fresh === "true"
            ? await router.readFresh(req.params.id)
            : router.getState(req.params.id);
        if (!state) return reply.code(404).send({ ok: false, error: "entity_not_found" });
        return reply.send({ ok: true, state });
      } catch (err) {
        return fail(reply, err);
      }
    },
  );

  // ---- direct canonical command ---------------------------------------------
  app.post<{ Body: Partial<CanonicalCommand> }>("/v2/command", async (req, reply) => {
    const body = req.body ?? {};
    if (!body.entityId || !body.capability || !body.action) {
      return reply.code(400).send({ ok: false, error: "bad_args", message: "entityId, capability, action required" });
    }
    try {
      const result = await router.dispatch({
        entityId: body.entityId,
        capability: body.capability,
        action: body.action,
        args: body.args,
        source: body.source ?? { ecosystem: "mock", controller: "api" },
      });
      return reply.send(result);
    } catch (err) {
      return fail(reply, err);
    }
  });

  // ---- native ingress (translate, then dispatch) ----------------------------
  app.post<{ Params: { ecosystem: string } }>("/v2/ingress/:ecosystem", async (req, reply) => {
    const adapter = controllerFor(router, req.params.ecosystem);
    if (!adapter) {
      return reply.code(404).send({ ok: false, error: "no_controller", message: `no controller for '${req.params.ecosystem}'` });
    }
    try {
      const commands = await adapter.controller.translateInbound(req.body);
      if (commands.length === 0) {
        return reply.code(422).send({ ok: false, error: "unrecognized", message: "no canonical command produced", echo: req.body });
      }
      const results = [];
      for (const cmd of commands) {
        try {
          results.push(await router.dispatch(cmd));
        } catch (err) {
          results.push(err instanceof TranslatorError ? err.toJSON() : { ok: false, error: "internal" });
        }
      }
      return reply.send({ ok: true, translated: commands.length, results });
    } catch (err) {
      return fail(reply, err);
    }
  });

  // ---- render state into a vendor feedback shape ----------------------------
  app.get<{ Params: { id: string; ecosystem: string } }>("/v2/entities/:id/render/:ecosystem", async (req, reply) => {
    const reg = router.registry.get(req.params.id);
    if (!reg) return reply.code(404).send({ ok: false, error: "entity_not_found" });
    const adapter = controllerFor(router, req.params.ecosystem);
    if (!adapter?.controller.renderState) {
      return reply.code(404).send({ ok: false, error: "no_renderer", message: `'${req.params.ecosystem}' cannot render feedback` });
    }
    const state = router.getState(req.params.id);
    if (!state) return reply.code(503).send({ ok: false, error: "no_state_yet" });
    return reply.send({ ok: true, rendered: adapter.controller.renderState(reg.entity, state) });
  });

  // ---- SSE event stream -----------------------------------------------------
  app.get("/v2/events", (req, reply) => {
    reply.hijack();
    reply.raw.writeHead(200, {
      "content-type": "text/event-stream",
      "cache-control": "no-cache",
      connection: "keep-alive",
    });
    reply.raw.write(`event: hello\ndata: ${JSON.stringify({ ok: true, at: Date.now() })}\n\n`);
    const unsub = router.onEvent((e) => {
      reply.raw.write(`data: ${JSON.stringify(e)}\n\n`);
    });
    const keepAlive = setInterval(() => reply.raw.write(": ping\n\n"), 15000);
    req.raw.on("close", () => {
      clearInterval(keepAlive);
      unsub();
    });
  });
}

// Small helper so /v2 root can label ecosystems if a UI wants it.
export { ECOSYSTEM_LABELS };
