// =============================================================================
// EcosystemAdapter — the one place vendor protocol knowledge is allowed.
// =============================================================================
//
// An ecosystem can play two roles, independently:
//
//   • DeviceHost   — it OWNS devices. It can list them, read their state, and
//                    apply canonical commands to them. (Rose, and the device
//                    side of Control4 / URC / Josh / Mock.)
//
//   • ControllerSide — it ISSUES commands. It translates a native controller
//                    payload (a Josh voice intent, a URC button press, a C4
//                    programming action) into canonical commands, and can
//                    render canonical state back into its native feedback shape.
//
// An adapter implements either role, or both. The router (./router.ts) wires
// the controller side of every adapter to the device side of every other —
// that cross-product is the "universal translator".

import type {
  CanonicalCommand,
  CanonicalEntity,
  CanonicalState,
  EcosystemId,
} from "./model.js";

// ---- Device-host role -------------------------------------------------------

export interface DeviceHost {
  // Enumerate the devices this adapter owns, as canonical entities. Called at
  // startup and may be re-called to rediscover.
  listEntities(): CanonicalEntity[] | Promise<CanonicalEntity[]>;

  // Read the current canonical state of one owned device.
  getState(entity: CanonicalEntity): Promise<CanonicalState>;

  // Apply a canonical command to one owned device. Throw TranslatorError on
  // bad input; the router maps that to an HTTP status.
  applyCommand(cmd: CanonicalCommand, entity: CanonicalEntity): Promise<void>;

  // Optional push model: if provided, the router subscribes instead of polling.
  // Return an unsubscribe function.
  subscribe?(onState: (entity: CanonicalEntity, state: CanonicalState) => void): () => void;

  // Poll cadence hint when `subscribe` is absent. Defaults to the router's.
  pollIntervalMs?: number;
}

// ---- Controller role --------------------------------------------------------

export interface ControllerSide {
  // Translate a native controller payload into zero or more canonical commands.
  // Returning [] is legal (e.g. an intent we recognized but that is a no-op).
  translateInbound(native: unknown): CanonicalCommand[] | Promise<CanonicalCommand[]>;

  // Render a canonical state snapshot into this ecosystem's native feedback
  // shape — URC "Universal Parse Data", a Josh now-playing card, a C4 variable
  // set. Optional: device-only feedback consumers can skip it.
  renderState?(entity: CanonicalEntity, state: CanonicalState): unknown;
}

// ---- The adapter ------------------------------------------------------------

export interface EcosystemAdapter {
  readonly ecosystem: EcosystemId;
  // Instance id — distinguishes two processors of the same ecosystem
  // (e.g. "urc-mrx-main" vs "urc-mrx-theater").
  readonly id: string;

  init?(): void | Promise<void>;
  shutdown?(): void | Promise<void>;

  // At least one of these is present.
  device?: DeviceHost;
  controller?: ControllerSide;
}

// Convenience guards used by the router and API.
export function isDeviceHost(a: EcosystemAdapter): a is EcosystemAdapter & { device: DeviceHost } {
  return a.device !== undefined;
}

export function isController(
  a: EcosystemAdapter,
): a is EcosystemAdapter & { controller: ControllerSide } {
  return a.controller !== undefined;
}
