// =============================================================================
// /v1 compatibility shim — the original Rose contract, now backed by the router.
// =============================================================================
//
// The original bridge exposed a Rose-specific /v1/* contract that the existing
// URC IP driver already speaks. We keep it working byte-for-byte, but it is now
// just one ecosystem's *view* onto the universal core: every /v1 call is
// translated to a canonical command/state against the Rose entity. Nothing in
// the field has to change, and yet the same device is now reachable by Control4
// and Josh too. This is the migration story in code form.

import type { FastifyInstance } from "fastify";
import type { TranslatorRouter } from "./router.js";
import type { BridgeConfig } from "../config.js";
import { CANONICAL_TO_ROSE_SOURCE, ROSE_SOURCE_TO_CANONICAL } from "./mappings.js";
import { TranslatorError } from "./model.js";
import { log } from "../logger.js";

interface PowerBody { state?: "on" | "off" | "toggle" }
interface SourceBody { input?: string }
interface VolumeBody { level?: number; delta?: number }
interface TransportBody { cmd?: string }

export function registerV1Shim(
  app: FastifyInstance,
  deps: { router: TranslatorRouter; config: BridgeConfig; startedAt: number },
): void {
  const { router, config, startedAt } = deps;

  const roseId = (): string | null => router.registry.list({ ecosystem: "rose" })[0]?.id ?? null;

  app.get("/v1/health", async (_req, reply) => {
    const id = roseId();
    const state = id ? router.getState(id) : null;
    const reachable = state?.reachable === true;
    return reply.code(reachable ? 200 : 503).send({
      ok: reachable,
      bridge: { uptimeSec: Math.floor((Date.now() - startedAt) / 1000), version: "0.2.0" },
      rose: {
        entityId: id,
        firmwarePin: config.roseFirmwarePin,
        reachable,
        ageMs: state?.ageMs ?? null,
      },
    });
  });

  app.get("/v1/state", async (_req, reply) => {
    const id = roseId();
    const state = id ? router.getState(id) : null;
    if (!state) return reply.code(503).send({ ok: false, error: "no_state_yet" });
    // Re-present canonical source as the original Rose enum name.
    const source = state.source ? CANONICAL_TO_ROSE_SOURCE[state.source] ?? "unknown" : "unknown";
    return reply.send({
      ok: true,
      power: state.power ?? "unknown",
      source,
      volume: state.volume?.level ?? null,
      playing: state.transport?.playing ?? false,
      ageMs: state.ageMs ?? null,
    });
  });

  app.post<{ Body: PowerBody }>("/v1/power", async (req, reply) => {
    const id = roseId();
    const desired = req.body?.state;
    if (!id) return reply.code(503).send({ ok: false, error: "rose_not_configured" });
    if (desired !== "on" && desired !== "off" && desired !== "toggle") {
      return reply.code(400).send({ ok: false, error: "expected state: on | off | toggle" });
    }
    try {
      await router.dispatch({
        entityId: id,
        capability: "power",
        action: desired === "toggle" ? "toggle" : "set",
        args: desired === "toggle" ? undefined : { state: desired },
        source: { ecosystem: "urc", controller: "v1" },
      });
      return reply.send({ ok: true, applied: desired });
    } catch (err) {
      return v1Fail(reply, err);
    }
  });

  app.post<{ Body: SourceBody }>("/v1/source", async (req, reply) => {
    const id = roseId();
    const input = req.body?.input;
    if (!id) return reply.code(503).send({ ok: false, error: "rose_not_configured" });
    if (!input || !(input in ROSE_SOURCE_TO_CANONICAL)) {
      return reply.code(400).send({ ok: false, error: "unknown input", accepted: Object.keys(ROSE_SOURCE_TO_CANONICAL) });
    }
    try {
      await router.dispatch({
        entityId: id,
        capability: "source",
        action: "set",
        args: { source: ROSE_SOURCE_TO_CANONICAL[input] },
        source: { ecosystem: "urc", controller: "v1" },
      });
      return reply.send({ ok: true, applied: input });
    } catch (err) {
      return v1Fail(reply, err);
    }
  });

  app.post<{ Body: VolumeBody }>("/v1/volume", async (req, reply) => {
    const id = roseId();
    const body = req.body ?? {};
    if (!id) return reply.code(503).send({ ok: false, error: "rose_not_configured" });
    const action = typeof body.level === "number" ? "set" : typeof body.delta === "number" ? "step" : null;
    if (!action) return reply.code(400).send({ ok: false, error: "expected level (0-100) or delta" });
    try {
      await router.dispatch({
        entityId: id,
        capability: "volume",
        action,
        args: action === "set" ? { level: body.level } : { delta: body.delta },
        source: { ecosystem: "urc", controller: "v1" },
      });
      return reply.send({ ok: true, applied: action === "set" ? body.level : { delta: body.delta } });
    } catch (err) {
      return v1Fail(reply, err);
    }
  });

  app.post<{ Body: TransportBody }>("/v1/transport", async (req, reply) => {
    const cmd = req.body?.cmd;
    if (!cmd) return reply.code(400).send({ ok: false, error: "expected cmd" });
    return reply.code(501).send({
      ok: false,
      error: "not implemented",
      note: "Rose transport control is Phase 2 (endpoints unverified).",
      requested: cmd,
    });
  });

  log.info("/v1 compatibility shim mounted (Rose-backed via universal router)");
}

function v1Fail(reply: import("fastify").FastifyReply, err: unknown) {
  if (err instanceof TranslatorError) {
    const status = err.code === "adapter_unreachable" ? 502 : err.httpStatus;
    return reply.code(status).send({ ok: false, error: err.code === "adapter_unreachable" ? "rose_unreachable" : err.code, details: err.message });
  }
  return reply.code(502).send({ ok: false, error: "rose_unreachable", details: (err as Error).message });
}
