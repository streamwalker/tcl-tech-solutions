// =============================================================================
// EntityRegistry — the lookup table from canonical entity id -> owning adapter.
// =============================================================================
//
// The router consults this on every command: "who actually owns
// rose:media_player:listening-room?" It also powers /v2/entities and the
// room/type/ecosystem filters a controller uses to discover what it can reach.

import type { EcosystemAdapter } from "./adapter.js";
import type { CanonicalEntity, EcosystemId, EntityType } from "./model.js";

export interface RegisteredEntity {
  entity: CanonicalEntity;
  // The device-host adapter that owns it.
  adapter: EcosystemAdapter;
}

export class EntityRegistry {
  private byId = new Map<string, RegisteredEntity>();

  upsert(entity: CanonicalEntity, adapter: EcosystemAdapter): void {
    this.byId.set(entity.id, { entity, adapter });
  }

  // Replace the full set owned by one adapter (used on (re)discovery so removed
  // devices disappear). Entities from other adapters are untouched.
  replaceForAdapter(adapterId: string, entities: CanonicalEntity[], adapter: EcosystemAdapter): void {
    for (const [id, reg] of this.byId) {
      if (reg.adapter.id === adapterId) this.byId.delete(id);
    }
    for (const e of entities) this.upsert(e, adapter);
  }

  get(id: string): RegisteredEntity | undefined {
    return this.byId.get(id);
  }

  has(id: string): boolean {
    return this.byId.has(id);
  }

  all(): RegisteredEntity[] {
    return [...this.byId.values()];
  }

  list(filter?: { ecosystem?: EcosystemId; type?: EntityType; room?: string }): CanonicalEntity[] {
    let out = [...this.byId.values()].map((r) => r.entity);
    if (filter?.ecosystem) out = out.filter((e) => e.ecosystem === filter.ecosystem);
    if (filter?.type) out = out.filter((e) => e.type === filter.type);
    if (filter?.room) out = out.filter((e) => e.room === filter.room);
    return out;
  }

  get size(): number {
    return this.byId.size;
  }
}
