// =============================================================================
// JoshAdapter — Josh AI (controller-primary) + device-host scaffold.
// =============================================================================
//
// CONTROLLER SIDE (fully implemented): Josh issues high-level natural-language
// intents ("mute the listening room", "play Roon in the den"). This adapter
// turns either a structured Nimble-style intent OR a raw utterance into
// canonical commands, resolving the spoken room/name to real entities via a
// resolver the router provides. That is what lets a Josh voice command drive a
// Control4 light or a Rose streamer.
//
// DEVICE SIDE (scaffold, gated): exposing Josh-managed devices to the others
// requires Josh's "Nimble DevSuite" partnership access — there is no open SDK
// (the implementation plan documents this). The host methods below are written
// to the right shape but stay disabled until a JoshClient is supplied; offline,
// Josh-owned devices are stood up by the MockAdapter instead.

import type { ControllerSide, DeviceHost, EcosystemAdapter } from "../adapter.js";
import {
  TranslatorError,
  type Capability,
  type CanonicalCommand,
  type CanonicalEntity,
  type CanonicalState,
  type CommandSource,
  type EntityType,
} from "../model.js";
import { normalizeSource } from "../mappings.js";

// The router/API supplies this so the adapter can turn "the kitchen" into
// entities without knowing the registry.
export type EntityResolver = (q: { room?: string; name?: string; type?: EntityType }) => CanonicalEntity[];

// Minimal contract a real Josh integration would implement (DevSuite-gated).
export interface JoshClient {
  listDevices(): Promise<CanonicalEntity[]>;
  getState(nativeId: string): Promise<CanonicalState>;
  apply(cmd: CanonicalCommand, entity: CanonicalEntity): Promise<void>;
}

interface ParsedIntent {
  capability: Capability;
  action: string;
  args?: Record<string, unknown>;
  target: { room?: string; name?: string };
  type?: EntityType;
}

export class JoshAdapter implements EcosystemAdapter {
  readonly ecosystem = "josh" as const;
  readonly id: string;
  controller: ControllerSide;
  device?: DeviceHost;

  private resolve: EntityResolver;

  constructor(opts: { id?: string; resolve: EntityResolver; client?: JoshClient }) {
    this.id = opts.id ?? "josh-core";
    this.resolve = opts.resolve;

    const self = this;
    this.controller = {
      translateInbound(native) {
        return self.translate(native);
      },
      renderState(entity, state) {
        return self.render(entity, state);
      },
    };

    // Device host only exists when a real Josh client is wired in.
    if (opts.client) {
      const client = opts.client;
      this.device = {
        listEntities: () => client.listDevices(),
        getState: (entity) => client.getState(entity.nativeId),
        applyCommand: (cmd, entity) => client.apply(cmd, entity),
      };
    }
  }

  // ---- controller: native -> canonical --------------------------------------

  private translate(native: unknown): CanonicalCommand[] {
    const parsed = this.parse(native);
    if (!parsed) return [];
    const source: CommandSource = { ecosystem: "josh", controller: parsed.target.room };
    const targets = this.resolve({ room: parsed.target.room, name: parsed.target.name, type: parsed.type }).filter(
      (e) => e.capabilities.includes(parsed.capability),
    );
    return targets.map((e) => ({
      entityId: e.id,
      capability: parsed.capability,
      action: parsed.action,
      args: parsed.args,
      source,
    }));
  }

  private parse(native: unknown): ParsedIntent | null {
    // Structured Nimble-style intent.
    if (native && typeof native === "object" && "intent" in native) {
      return this.parseStructured(native as Record<string, unknown>);
    }
    // Raw utterance (string, or { utterance }).
    const text =
      typeof native === "string"
        ? native
        : native && typeof native === "object" && typeof (native as { utterance?: unknown }).utterance === "string"
          ? (native as { utterance: string }).utterance
          : null;
    return text ? this.parseUtterance(text) : null;
  }

  private parseStructured(o: Record<string, unknown>): ParsedIntent | null {
    const intent = String(o.intent);
    const room = o.room !== undefined ? String(o.room) : undefined;
    const name = o.target !== undefined ? String(o.target) : undefined;
    const target = { room, name };
    switch (intent) {
      case "set_power":
        return { capability: "power", action: "set", args: { state: String(o.value) }, target };
      case "toggle_power":
        return { capability: "power", action: "toggle", target };
      case "mute":
        return { capability: "volume", action: "mute", args: { muted: true }, target };
      case "unmute":
        return { capability: "volume", action: "mute", args: { muted: false }, target };
      case "set_volume":
        return { capability: "volume", action: "set", args: { level: Number(o.value) }, target };
      case "select_source":
        return { capability: "source", action: "set", args: { source: normalizeSource(String(o.value)) }, target };
      case "transport":
        return { capability: "transport", action: String(o.value), target };
      case "set_brightness":
        return { capability: "brightness", action: "set", args: { level: Number(o.value) }, target, type: "light" };
      case "set_temperature":
        return { capability: "climate", action: "set", args: { setpoint: Number(o.value) }, target, type: "thermostat" };
      case "lock":
        return { capability: "lock", action: "set", args: { state: "locked" }, target, type: "lock" };
      case "unlock":
        return { capability: "lock", action: "set", args: { state: "unlocked" }, target, type: "lock" };
      default:
        return null;
    }
  }

  // Pragmatic NL parser. Not a substitute for Josh's real NLU — just enough to
  // demonstrate and test the path utterance -> canonical without Josh hardware.
  private parseUtterance(raw: string): ParsedIntent | null {
    const t = raw.trim().toLowerCase();
    const room = this.extractRoom(t);
    const num = t.match(/\b(\d{1,3})\b/);

    if (/\b(lock)\b/.test(t) && !/unlock/.test(t))
      return { capability: "lock", action: "set", args: { state: "locked" }, target: { room }, type: "lock" };
    if (/\bunlock\b/.test(t))
      return { capability: "lock", action: "set", args: { state: "unlocked" }, target: { room }, type: "lock" };

    if (/\b(\d{1,3})\s*(degrees|degree|°)\b/.test(t) || /thermostat|temperature/.test(t)) {
      if (num) return { capability: "climate", action: "set", args: { setpoint: Number(num[1]) }, target: { room }, type: "thermostat" };
    }

    if (/\b(dim|brightness|lights?)\b/.test(t)) {
      if (num) return { capability: "brightness", action: "set", args: { level: Number(num[1]) }, target: { room }, type: "light" };
      if (/\b(turn on|on)\b/.test(t)) return { capability: "power", action: "set", args: { state: "on" }, target: { room }, type: "light" };
      if (/\b(turn off|off)\b/.test(t)) return { capability: "power", action: "set", args: { state: "off" }, target: { room }, type: "light" };
    }

    if (/\bunmute\b/.test(t)) return { capability: "volume", action: "mute", args: { muted: false }, target: { room } };
    if (/\bmute\b/.test(t)) return { capability: "volume", action: "mute", args: { muted: true }, target: { room } };

    if (/\bvolume\b/.test(t) && num) return { capability: "volume", action: "set", args: { level: Number(num[1]) }, target: { room } };
    if (/\b(turn it up|louder|volume up)\b/.test(t)) return { capability: "volume", action: "step", args: { delta: 5 }, target: { room } };
    if (/\b(turn it down|quieter|volume down)\b/.test(t)) return { capability: "volume", action: "step", args: { delta: -5 }, target: { room } };

    if (/\b(pause)\b/.test(t)) return { capability: "transport", action: "pause", target: { room } };
    if (/\b(stop)\b/.test(t)) return { capability: "transport", action: "stop", target: { room } };
    if (/\b(next|skip)\b/.test(t)) return { capability: "transport", action: "next", target: { room } };
    if (/\b(previous|back)\b/.test(t)) return { capability: "transport", action: "previous", target: { room } };

    const srcMatch = t.match(/\b(?:play|switch to|put on|set source to)\s+(roon|spotify|airplay|bluetooth|optical|usb|line in|aux|tuner|radio)\b/);
    if (srcMatch) return { capability: "source", action: "set", args: { source: normalizeSource(srcMatch[1]) }, target: { room } };
    if (/\bplay\b/.test(t)) return { capability: "transport", action: "play", target: { room } };

    if (/\b(turn on|power on|switch on)\b/.test(t)) return { capability: "power", action: "set", args: { state: "on" }, target: { room } };
    if (/\b(turn off|power off|switch off|shut off)\b/.test(t)) return { capability: "power", action: "set", args: { state: "off" }, target: { room } };

    return null;
  }

  // "...in the listening room" / "the kitchen lights" -> "listening room"/"kitchen".
  private extractRoom(t: string): string | undefined {
    const inMatch = t.match(/\bin (?:the )?([a-z][a-z ]+?)(?:\s+(?:room|zone))?$/);
    if (inMatch) return inMatch[1].trim();
    const theMatch = t.match(/\bthe ([a-z][a-z ]+?) (?:lights?|speakers?|thermostat|door|tv|stereo)\b/);
    if (theMatch) return theMatch[1].trim();
    return undefined;
  }

  // ---- controller: canonical state -> Josh feedback card --------------------

  private render(entity: CanonicalEntity, state: CanonicalState): unknown {
    return {
      device: entity.name,
      room: entity.room,
      online: state.reachable,
      power: state.power,
      volume: state.volume?.level,
      muted: state.volume?.muted,
      source: state.source,
      nowPlaying: state.transport?.track,
    };
  }
}

// Re-exported so the API layer can construct a "device unavailable" host that
// makes the partnership requirement explicit if someone enables Josh hosting
// without credentials.
export function joshDeviceUnavailable(): never {
  throw new TranslatorError(
    "not_implemented",
    "Josh device hosting requires Nimble DevSuite access (partnership-gated). See implementation plan §3.3.",
  );
}
