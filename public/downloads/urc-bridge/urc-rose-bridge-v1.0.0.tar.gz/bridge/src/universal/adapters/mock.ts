// =============================================================================
// MockAdapter — fully in-memory device host. No hardware, no network.
// =============================================================================
//
// Purpose:
//   • Lets the whole translator run end-to-end offline (CI, demos, the SaaS
//     simulator) so you can prove "a Josh intent drove a Control4-only device"
//     without owning a Control4 controller.
//   • Is the device target in the test suite.
//
// It holds a CanonicalState per entity and mutates it on applyCommand exactly
// as a real device would, so the router's dispatch + state-diff + event path is
// exercised for real.

import type { DeviceHost, EcosystemAdapter } from "../adapter.js";
import {
  TranslatorError,
  type Capability,
  type CanonicalCommand,
  type CanonicalEntity,
  type CanonicalState,
  type EcosystemId,
  type EntityType,
} from "../model.js";
import { clampLevel } from "../mappings.js";

export interface MockEntitySpec {
  slug: string;
  type: EntityType;
  name: string;
  room?: string;
  capabilities: Capability[];
  initial?: Partial<CanonicalState>;
  // The ecosystem this mock device pretends to belong to. This is the whole
  // point of the demo: a device that "only works with Control4" is a mock
  // entity with ecosystem:"control4".
  ecosystem?: EcosystemId;
}

export class MockAdapter implements EcosystemAdapter {
  readonly ecosystem: EcosystemId;
  readonly id: string;
  device: DeviceHost;

  private entities: CanonicalEntity[] = [];
  private states = new Map<string, CanonicalState>();

  constructor(opts: { id?: string; ecosystem?: EcosystemId; entities: MockEntitySpec[] }) {
    this.ecosystem = opts.ecosystem ?? "mock";
    this.id = opts.id ?? `mock-${this.ecosystem}`;

    for (const spec of opts.entities) {
      const eco = spec.ecosystem ?? this.ecosystem;
      const id = `${eco}:${spec.type}:${spec.slug}`;
      this.entities.push({
        id,
        type: spec.type,
        name: spec.name,
        room: spec.room,
        ecosystem: eco,
        nativeId: spec.slug,
        capabilities: spec.capabilities,
      });
      this.states.set(id, {
        entityId: id,
        reachable: true,
        power: spec.capabilities.includes("power") ? "off" : undefined,
        volume: spec.capabilities.includes("volume") ? { level: 20, muted: false } : undefined,
        source: spec.capabilities.includes("source") ? "optical" : undefined,
        transport: spec.capabilities.includes("transport") ? { playing: false } : undefined,
        brightness: spec.capabilities.includes("brightness") ? 0 : undefined,
        climate: spec.capabilities.includes("climate") ? { mode: "off", current: 21, setpoint: 21, units: "C" } : undefined,
        lock: spec.capabilities.includes("lock") ? "locked" : undefined,
        position: spec.capabilities.includes("position") ? 0 : undefined,
        ...spec.initial,
      });
    }

    const self = this;
    this.device = {
      listEntities() {
        return self.entities;
      },
      async getState(entity) {
        const s = self.states.get(entity.id);
        if (!s) throw new TranslatorError("entity_not_found", `mock: ${entity.id}`);
        return { ...s };
      },
      async applyCommand(cmd, entity) {
        self.mutate(cmd, entity);
      },
    };
  }

  private mutate(cmd: CanonicalCommand, entity: CanonicalEntity): void {
    const s = this.states.get(entity.id);
    if (!s) throw new TranslatorError("entity_not_found", `mock: ${entity.id}`);

    switch (cmd.capability) {
      case "power": {
        if (cmd.action === "toggle") s.power = s.power === "on" ? "off" : "on";
        else {
          const v = cmd.args?.state;
          if (v !== "on" && v !== "off") throw new TranslatorError("bad_args", "power.set needs state on|off");
          s.power = v;
        }
        break;
      }
      case "volume": {
        const vol = s.volume ?? { level: 0, muted: false };
        if (cmd.action === "mute") vol.muted = cmd.args?.muted === undefined ? !vol.muted : Boolean(cmd.args.muted);
        else if (cmd.action === "step") vol.level = clampLevel((vol.level ?? 0) + Number(cmd.args?.delta ?? 0));
        else vol.level = clampLevel(Number(cmd.args?.level ?? vol.level ?? 0));
        s.volume = vol;
        break;
      }
      case "source": {
        s.source = String(cmd.args?.source ?? s.source ?? "");
        break;
      }
      case "transport": {
        const t = s.transport ?? { playing: false };
        if (cmd.action === "play") t.playing = true;
        else if (cmd.action === "pause" || cmd.action === "stop") t.playing = false;
        else if (cmd.action === "toggle") t.playing = !t.playing;
        s.transport = t;
        break;
      }
      case "brightness": {
        if (cmd.action === "step") s.brightness = clampLevel((s.brightness ?? 0) + Number(cmd.args?.delta ?? 0));
        else s.brightness = clampLevel(Number(cmd.args?.level ?? s.brightness ?? 0));
        // A light at >0 brightness is implicitly on.
        if (entity.capabilities.includes("power")) s.power = (s.brightness ?? 0) > 0 ? "on" : "off";
        break;
      }
      case "climate": {
        const c = s.climate ?? {};
        if (cmd.args?.setpoint !== undefined) c.setpoint = Number(cmd.args.setpoint);
        if (cmd.args?.mode !== undefined) c.mode = cmd.args.mode as NonNullable<CanonicalState["climate"]>["mode"];
        s.climate = c;
        break;
      }
      case "lock": {
        if (cmd.action === "toggle") s.lock = s.lock === "locked" ? "unlocked" : "locked";
        else s.lock = cmd.args?.state === "unlocked" ? "unlocked" : "locked";
        break;
      }
      case "position": {
        if (cmd.action === "open") s.position = 100;
        else if (cmd.action === "close") s.position = 0;
        else if (cmd.action === "set") s.position = clampLevel(Number(cmd.args?.position ?? s.position ?? 0));
        break;
      }
      case "activate":
        // Scenes are stateless; nothing to mutate. Existence is the success.
        break;
      default:
        throw new TranslatorError("capability_unsupported", `mock: ${cmd.capability}`);
    }
  }
}

// A ready-made set of "trapped" devices for demos and tests: each lives in an
// ecosystem the others natively cannot reach.
export function demoMockAdapter(): MockAdapter {
  return new MockAdapter({
    id: "mock-demo",
    entities: [
      {
        slug: "living-room-lights",
        type: "light",
        name: "Living Room Lights",
        room: "Living Room",
        ecosystem: "control4", // a Control4-only dimmer
        capabilities: ["power", "brightness"],
      },
      {
        slug: "front-door",
        type: "lock",
        name: "Front Door Lock",
        room: "Entry",
        ecosystem: "control4",
        capabilities: ["lock"],
      },
      {
        slug: "thermostat",
        type: "thermostat",
        name: "Main Thermostat",
        room: "Hallway",
        ecosystem: "josh", // a Josh-managed thermostat
        capabilities: ["climate"],
      },
      {
        slug: "patio-speakers",
        type: "media_player",
        name: "Patio Speakers",
        room: "Patio",
        ecosystem: "urc", // a URC-only zone amp
        capabilities: ["power", "volume", "source", "transport"],
      },
    ],
  });
}
