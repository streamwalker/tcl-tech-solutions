// =============================================================================
// URC ASCII path — token-secured ASCII command transport + parse-data codec.
// =============================================================================
//
// Per URC guidance, the supported, low-risk integration is a SECURED ASCII
// command channel (over IP or serial) using URC's basic SDK — NOT a C++/Visual
// C++ Accelerator driver (that is co-developing URC's own software). One-way
// command control is simple: format an ASCII frame and send it. Two-way is the
// work: parse the ASCII that comes back and map it to state with variable rules
// (the same shape as Autonomics/Sonos drivers).
//
// This module models exactly that:
//   • UrcAsciiTransport — a pluggable, token-authenticated channel. The token
//     handshake is the transport's concern; the codec never sees credentials.
//   • encodeCommand     — canonical command  -> ASCII frame (configurable map).
//   • parseResponse     — ASCII response     -> canonical state (rules table).
//   • makeUrcAsciiDeviceHost — wires the two into a DeviceHost.
//
// The default command map and parse rules below are a working PLACEHOLDER
// convention so the system runs and tests pass. Swap the tokens/templates for
// URC's actual ASCII syntax once the SDK is in hand — it is a data change, not
// a rewrite.

import type { DeviceHost } from "../adapter.js";
import {
  TranslatorError,
  type CanonicalCommand,
  type CanonicalEntity,
  type CanonicalState,
} from "../model.js";
import { clampLevel } from "../mappings.js";

// ---- Transport (token handshake lives here) --------------------------------

export interface UrcAsciiTransportConfig {
  host?: string; // IP transport
  port?: number;
  serialPath?: string; // serial transport (e.g. /dev/tty.usbserial)
  baud?: number;
  token: string; // secured-protocol credential; used only inside connect()
  terminator?: string; // frame terminator, default "\r"
}

// A connection that performs the secured (token) handshake on connect(), then
// carries plain ASCII frames. send() is fire-and-forget (one-way control);
// query() sends and reads the response (two-way feedback). Implementations
// supply the real socket/serial + token handshake; the adapter stays agnostic.
export interface UrcAsciiTransport {
  readonly connected: boolean;
  connect(): Promise<void>;
  send(frame: string): Promise<void>;
  query?(frame: string): Promise<string>;
  close(): Promise<void>;
}

// ---- Command map (canonical -> ASCII) --------------------------------------

// Templates may reference {value}, {index}, {zone}. Anything unmapped yields a
// null frame, which the device host reports as unsupported rather than guessing.
export interface UrcAsciiCommandMap {
  terminator: string;
  statusQuery: string; // frame that asks the device for its current state
  power_on: string;
  power_off: string;
  power_toggle?: string;
  volume_set: string; // uses {value}
  volume_up: string;
  volume_down: string;
  mute_toggle: string;
  source_set: string; // uses {index}
  transport: Record<string, string>; // play/pause/stop/next/previous
}

export const DEFAULT_URC_COMMAND_MAP: UrcAsciiCommandMap = {
  terminator: "\r",
  statusQuery: "STATUS?",
  power_on: "PWR ON",
  power_off: "PWR OFF",
  power_toggle: "PWR TOGGLE",
  volume_set: "VOL {value}",
  volume_up: "VOL UP",
  volume_down: "VOL DOWN",
  mute_toggle: "MUTE",
  source_set: "INPUT {index}",
  transport: { play: "PLAY", pause: "PAUSE", stop: "STOP", next: "NEXT", previous: "PREV" },
};

// Default canonical-source -> URC input index (mirror of the controller map).
export const DEFAULT_INPUT_INDEX: Record<string, number> = {
  line_in: 1,
  optical: 2,
  earc: 3,
  usb: 4,
  aes_ebu: 5,
};

function fill(tpl: string, vars: Record<string, string | number>): string {
  return tpl.replace(/\{(\w+)\}/g, (_, k) => (k in vars ? String(vars[k]) : `{${k}}`));
}

// canonical command -> ASCII frame (without terminator), or null if unmappable.
export function encodeCommand(
  cmd: CanonicalCommand,
  map: UrcAsciiCommandMap,
  inputIndex: Record<string, number>,
  entity?: CanonicalEntity,
): string | null {
  const zone = entity?.nativeId ?? "";
  const wrap = (frame: string | undefined): string | null =>
    frame === undefined ? null : fill(frame, { zone });

  switch (cmd.capability) {
    case "power":
      if (cmd.action === "toggle") return wrap(map.power_toggle);
      return wrap(cmd.args?.state === "off" ? map.power_off : map.power_on);
    case "volume":
      if (cmd.action === "mute") return wrap(map.mute_toggle);
      if (cmd.action === "step") return wrap(Number(cmd.args?.delta) >= 0 ? map.volume_up : map.volume_down);
      return wrap(fill(map.volume_set, { value: clampLevel(Number(cmd.args?.level ?? 0)), zone }));
    case "source": {
      const idx = inputIndex[String(cmd.args?.source ?? "")];
      if (idx === undefined) return null;
      return wrap(fill(map.source_set, { index: idx, zone }));
    }
    case "transport":
      return wrap(map.transport[cmd.action]);
    default:
      return null;
  }
}

// ---- Response parser (ASCII -> canonical state) ----------------------------

// "If it receives this, set that." A rule matches one response line and mutates
// the accumulating state. This is the data-driven Universal Parse Data layer.
export interface UrcParseRule {
  match: RegExp;
  apply: (m: RegExpMatchArray, s: CanonicalState) => void;
}

export function defaultParseRules(inputIndex: Record<string, number>): UrcParseRule[] {
  const indexToSource: Record<number, string> = {};
  for (const [src, idx] of Object.entries(inputIndex)) indexToSource[idx] = src;
  return [
    { match: /^PWR=(ON|OFF)$/i, apply: (m, s) => { s.power = m[1].toUpperCase() === "ON" ? "on" : "off"; } },
    { match: /^VOL=(\d+)$/i, apply: (m, s) => { s.volume = { level: clampLevel(Number(m[1])), muted: s.volume?.muted ?? false }; } },
    { match: /^MUTE=([01])$/i, apply: (m, s) => { s.volume = { level: s.volume?.level ?? null, muted: m[1] === "1" }; } },
    { match: /^INPUT=(\d+)$/i, apply: (m, s) => { s.source = indexToSource[Number(m[1])] ?? `input${m[1]}`; } },
    { match: /^PLAY=([01])$/i, apply: (m, s) => { s.transport = { playing: m[1] === "1" }; } },
  ];
}

export function parseResponse(raw: string, rules: UrcParseRule[], entityId: string): CanonicalState {
  const state: CanonicalState = { entityId, reachable: true, raw };
  for (const line of raw.split(/\r?\n|\r/)) {
    const t = line.trim();
    if (!t) continue;
    for (const rule of rules) {
      const m = t.match(rule.match);
      if (m) { rule.apply(m, state); break; }
    }
  }
  return state;
}

// ---- Device-host factory ----------------------------------------------------

export interface UrcAsciiHostOptions {
  transport: UrcAsciiTransport;
  entities: CanonicalEntity[]; // URC-owned devices/zones this processor exposes
  commandMap?: UrcAsciiCommandMap;
  parseRules?: UrcParseRule[];
  inputIndex?: Record<string, number>;
  pollIntervalMs?: number;
}

// Build a DeviceHost backed by a token-secured ASCII transport. applyCommand
// encodes + sends one-way; getState queries + parses (two-way) when the
// transport supports query().
export function makeUrcAsciiDeviceHost(opts: UrcAsciiHostOptions): DeviceHost {
  const map = opts.commandMap ?? DEFAULT_URC_COMMAND_MAP;
  const inputIndex = opts.inputIndex ?? DEFAULT_INPUT_INDEX;
  const rules = opts.parseRules ?? defaultParseRules(inputIndex);
  const t = opts.transport;

  async function ensure(): Promise<void> {
    if (!t.connected) await t.connect(); // performs the token handshake
  }

  return {
    pollIntervalMs: opts.pollIntervalMs,
    listEntities() {
      return opts.entities;
    },
    async getState(entity) {
      if (!t.query) {
        // One-way transport: we can command but cannot read back.
        return { entityId: entity.id, reachable: t.connected };
      }
      try {
        await ensure();
        const frame = fill(map.statusQuery, { zone: entity.nativeId }) + map.terminator;
        const resp = await t.query(frame);
        return parseResponse(resp, rules, entity.id);
      } catch (err) {
        throw new TranslatorError("adapter_unreachable", `urc ascii query failed: ${(err as Error).message}`);
      }
    },
    async applyCommand(cmd, entity) {
      const body = encodeCommand(cmd, map, inputIndex, entity);
      if (body === null) {
        throw new TranslatorError("not_implemented", `urc ascii: no command mapping for ${cmd.capability}.${cmd.action}`);
      }
      try {
        await ensure();
        await t.send(body + map.terminator);
      } catch (err) {
        throw new TranslatorError("adapter_unreachable", `urc ascii send failed: ${(err as Error).message}`);
      }
    },
  };
}
