// =============================================================================
// Control4Adapter — Director device-host + programming controller-side.
// =============================================================================
//
// DEVICE SIDE: Control4 controllers run "Director". There is no published public
// API, but the local Director protocol is well-understood from the open-source
// pyControl4 work (used by the Home Assistant integration): you authenticate to
// the controller, then issue GET_DEVICES / variable reads / SEND_COMMAND against
// integer device ids. This adapter is built to that shape so that — given a
// controller IP and a Director bearer token — it exposes Control4 devices
// (lights, locks, thermostats, AV) as canonical entities the others can drive.
// Until a Control4Director client is supplied, the host stays inert (lists no
// devices) rather than pretending.
//
// CONTROLLER SIDE: Control4 "programming" / a DriverWorks proxy driver relays an
// action to the bridge. translateInbound turns that native action into canonical
// commands; renderState produces the C4 variable writes a proxy driver consumes
// for two-way feedback.

import type { ControllerSide, DeviceHost, EcosystemAdapter } from "../adapter.js";
import {
  TranslatorError,
  type Capability,
  type CanonicalCommand,
  type CanonicalEntity,
  type CanonicalState,
  type CommandSource,
  type EntityType,
} from "../model.js";
import { clampLevel, normalizeSource } from "../mappings.js";

// The slice of Director a live integration must implement. Auth/transport
// (token acquisition, wss/https to the controller) lives in the implementation.
export interface Control4Director {
  getDevices(): Promise<Array<{ id: number; proxy: string; name: string; roomName?: string }>>;
  getStateVars(deviceId: number): Promise<Record<string, unknown>>;
  sendCommand(deviceId: number, command: string, params?: Record<string, unknown>): Promise<void>;
}

// Control4 "proxy" string -> canonical type + capabilities.
function mapProxy(proxy: string): { type: EntityType; capabilities: Capability[] } {
  switch (proxy) {
    case "light":
    case "dimmer":
      return { type: "light", capabilities: ["power", "brightness"] };
    case "relay":
    case "switch":
    case "outlet":
      return { type: "switch", capabilities: ["power"] };
    case "thermostat":
      return { type: "thermostat", capabilities: ["climate"] };
    case "lock":
      return { type: "lock", capabilities: ["lock"] };
    case "blind":
    case "shade":
      return { type: "shade", capabilities: ["position"] };
    case "amplifier":
    case "receiver":
    case "avswitch":
    case "media_service":
      return { type: "media_player", capabilities: ["power", "volume", "source", "transport"] };
    default:
      return { type: "generic", capabilities: ["power"] };
  }
}

export class Control4Adapter implements EcosystemAdapter {
  readonly ecosystem = "control4" as const;
  readonly id: string;
  controller: ControllerSide;
  device?: DeviceHost;

  private director?: Control4Director;
  private idMap = new Map<string, number>(); // canonical id -> C4 device id

  constructor(opts: { id?: string; director?: Control4Director } = {}) {
    this.id = opts.id ?? "control4-main";
    this.director = opts.director;

    const self = this;
    this.controller = {
      translateInbound(native) {
        return self.translate(native);
      },
      renderState(entity, state) {
        return self.render(entity, state);
      },
    };

    if (this.director) {
      const director = this.director;
      this.device = {
        async listEntities() {
          const devices = await director.getDevices();
          return devices.map((d) => {
            const m = mapProxy(d.proxy);
            const id = `control4:${m.type}:${d.id}`;
            self.idMap.set(id, d.id);
            return {
              id,
              type: m.type,
              name: d.name,
              room: d.roomName,
              ecosystem: "control4" as const,
              nativeId: String(d.id),
              capabilities: m.capabilities,
            };
          });
        },
        async getState(entity) {
          const vars = await director.getStateVars(Number(entity.nativeId));
          return self.varsToState(entity, vars);
        },
        async applyCommand(cmd, entity) {
          const { command, params } = self.toDirectorCommand(cmd);
          await director.sendCommand(Number(entity.nativeId), command, params);
        },
      };
    }
  }

  // ---- canonical -> Director SEND_COMMAND -----------------------------------

  private toDirectorCommand(cmd: CanonicalCommand): { command: string; params?: Record<string, unknown> } {
    switch (cmd.capability) {
      case "power":
        if (cmd.action === "toggle") return { command: "TOGGLE" };
        return { command: cmd.args?.state === "on" ? "ON" : "OFF" };
      case "brightness":
        return { command: "RAMP_TO_LEVEL", params: { LEVEL: clampLevel(Number(cmd.args?.level ?? 0)), TIME: 0 } };
      case "volume":
        if (cmd.action === "mute") return { command: "MUTE_TOGGLE" };
        if (cmd.action === "step") return { command: Number(cmd.args?.delta) >= 0 ? "PULSE_VOL_UP" : "PULSE_VOL_DOWN" };
        return { command: "SET_VOLUME_LEVEL", params: { LEVEL: clampLevel(Number(cmd.args?.level ?? 0)) } };
      case "source":
        return { command: "SET_INPUT", params: { INPUT: String(cmd.args?.source ?? "") } };
      case "transport":
        return { command: cmd.action.toUpperCase() };
      case "climate":
        return { command: "SET_SETPOINT_SINGLE", params: { SETPOINT: Number(cmd.args?.setpoint ?? 0) } };
      case "lock":
        return { command: cmd.args?.state === "unlocked" ? "UNLOCK" : "LOCK" };
      case "position":
        if (cmd.action === "open") return { command: "OPEN" };
        if (cmd.action === "close") return { command: "CLOSE" };
        return { command: "SET_LEVEL_TARGET", params: { TARGET: clampLevel(Number(cmd.args?.position ?? 0)) } };
      default:
        throw new TranslatorError("capability_unsupported", `control4: ${cmd.capability}`);
    }
  }

  // ---- Director variables -> canonical state --------------------------------

  private varsToState(entity: CanonicalEntity, vars: Record<string, unknown>): CanonicalState {
    const num = (k: string): number | undefined => {
      const v = vars[k];
      return typeof v === "number" ? v : typeof v === "string" && v !== "" ? Number(v) : undefined;
    };
    const state: CanonicalState = { entityId: entity.id, reachable: true, raw: vars };
    if (entity.capabilities.includes("power")) {
      const lvl = num("LIGHT_LEVEL") ?? num("POWER_STATE");
      state.power = (lvl ?? 0) > 0 ? "on" : "off";
    }
    if (entity.capabilities.includes("brightness")) state.brightness = num("LIGHT_LEVEL") ?? null;
    if (entity.capabilities.includes("volume")) state.volume = { level: num("CURRENT_VOLUME") ?? null, muted: vars.IS_MUTED === true };
    if (entity.capabilities.includes("climate"))
      state.climate = { setpoint: num("HEAT_SETPOINT_F") ?? num("SETPOINT") ?? null, current: num("TEMPERATURE_F") ?? null, units: "F" };
    if (entity.capabilities.includes("lock")) state.lock = vars.LOCK_STATE === true || vars.LOCK_STATE === 1 ? "locked" : "unlocked";
    return state;
  }

  // ---- controller: native C4 action -> canonical ----------------------------

  private translate(native: unknown): CanonicalCommand[] {
    if (!native || typeof native !== "object") return [];
    const o = native as Record<string, unknown>;
    const entityId = typeof o.entityId === "string" ? o.entityId : undefined;
    if (!entityId) return []; // a C4 proxy driver is configured with the target canonical id
    const source: CommandSource = { ecosystem: "control4", controller: typeof o.agent === "string" ? o.agent : undefined };

    // Accept either a canonical {capability, action, args} relay or a raw C4
    // command verb ({command:"ON"|"OFF"|"SET_LEVEL"|...}).
    if (typeof o.capability === "string" && typeof o.action === "string") {
      return [{ entityId, capability: o.capability as Capability, action: o.action, args: o.args as Record<string, unknown> | undefined, source }];
    }
    const command = typeof o.command === "string" ? o.command.toUpperCase() : "";
    const mapped = this.fromDirectorCommand(command, o);
    return mapped ? [{ ...mapped, entityId, source }] : [];
  }

  private fromDirectorCommand(command: string, o: Record<string, unknown>): Omit<CanonicalCommand, "entityId" | "source"> | null {
    const level = Number(o.level ?? o.LEVEL);
    switch (command) {
      case "ON":
        return { capability: "power", action: "set", args: { state: "on" } };
      case "OFF":
        return { capability: "power", action: "set", args: { state: "off" } };
      case "TOGGLE":
        return { capability: "power", action: "toggle" };
      case "SET_LEVEL":
      case "RAMP_TO_LEVEL":
        return { capability: "brightness", action: "set", args: { level } };
      case "SET_VOLUME_LEVEL":
        return { capability: "volume", action: "set", args: { level } };
      case "MUTE_TOGGLE":
      case "MUTE_ON":
      case "MUTE_OFF":
        return { capability: "volume", action: "mute", args: { muted: command !== "MUTE_OFF" } };
      case "SET_INPUT":
        return { capability: "source", action: "set", args: { source: normalizeSource(String(o.input ?? o.INPUT ?? "")) } };
      case "PLAY":
      case "PAUSE":
      case "STOP":
      case "NEXT":
      case "PREVIOUS":
        return { capability: "transport", action: command.toLowerCase() };
      case "LOCK":
        return { capability: "lock", action: "set", args: { state: "locked" } };
      case "UNLOCK":
        return { capability: "lock", action: "set", args: { state: "unlocked" } };
      default:
        return null;
    }
  }

  // ---- controller: canonical state -> C4 variable writes --------------------

  private render(_entity: CanonicalEntity, state: CanonicalState): unknown {
    const variables: Record<string, unknown> = { ONLINE: state.reachable };
    if (state.power !== undefined) variables.POWER_STATE = state.power === "on" ? 1 : 0;
    if (state.brightness != null) variables.LIGHT_LEVEL = state.brightness;
    if (state.volume) {
      variables.CURRENT_VOLUME = state.volume.level;
      variables.IS_MUTED = state.volume.muted;
    }
    if (state.source != null) variables.CURRENT_INPUT = state.source;
    if (state.lock) variables.LOCK_STATE = state.lock === "locked";
    return { variables };
  }
}
