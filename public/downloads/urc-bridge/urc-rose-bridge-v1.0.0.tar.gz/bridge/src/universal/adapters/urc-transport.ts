// =============================================================================
// Concrete URC ASCII transports — IP (TCP) and serial — with token handshake.
// =============================================================================
//
// These are the real channels that satisfy UrcAsciiTransport (see urc-ascii.ts).
// They are ready the moment URC provides the SDK token:
//
//   • createUrcTcpTransport({ host, port, token })  — ASCII over TCP, using the
//     Node built-in `node:net` (no new dependencies).
//   • createUrcSerialTransport(() => serialPort, { token }) — ASCII over a serial
//     stream. We do NOT bundle the `serialport` package; the integrator passes a
//     factory returning any Node Duplex stream (a `SerialPort` instance is one),
//     keeping the bridge dependency-free.
//
// The "secured protocol requiring a token" is handled in connect() via a
// pluggable handshake. The DEFAULT handshake presents `AUTH <token>` and treats
// a NACK/ERR/DENY reply as failure — confirm and override against the real URC
// SDK once available; it is a one-function change.

import net from "node:net";
import { Duplex } from "node:stream";
import { log } from "../../logger.js";
import type { UrcAsciiTransport } from "./urc-ascii.js";

export interface UrcHandshakeIO {
  token: string;
  term: string;
  send: (frame: string) => void;
  query: (frame: string, maxMs?: number) => Promise<string>;
}
export type UrcHandshake = (io: UrcHandshakeIO) => Promise<void>;

export interface UrcTransportOptions {
  token: string;
  terminator?: string; // default "\r"
  connectTimeoutMs?: number; // default 5000
  quietMs?: number; // response is "done" after this idle gap; default 150
  queryTimeoutMs?: number; // hard cap on a query; default 3000
  handshake?: UrcHandshake; // override the secured handshake per URC SDK
}

// Default secured handshake: present the token, fail on an explicit rejection.
export const defaultHandshake: UrcHandshake = async (io) => {
  const resp = await io.query(`AUTH ${io.token}${io.term}`, 1500);
  if (/\b(NACK|ERR|ERROR|DENY|DENIED|FAIL|UNAUTH)\b/i.test(resp)) {
    throw new Error(`URC auth rejected: ${resp.trim() || "(no response)"}`);
  }
};

// Generic ASCII transport over any Node Duplex stream. TCP and serial are just
// different stream factories.
export class UrcStreamTransport implements UrcAsciiTransport {
  private stream: Duplex | null = null;
  private _connected = false;
  private connecting: Promise<void> | null = null;
  private acc = "";
  private waiter: { resolve: (s: string) => void; quiet: ReturnType<typeof setTimeout>; hard: ReturnType<typeof setTimeout> } | null = null;
  private readonly term: string;

  constructor(
    private readonly openStream: () => Promise<Duplex> | Duplex,
    private readonly opts: UrcTransportOptions,
  ) {
    this.term = opts.terminator ?? "\r";
  }

  get connected(): boolean {
    return this._connected;
  }

  // Dedupe concurrent connects (cache-prime + first command can race) so the
  // socket opens once and the token handshake runs once.
  async connect(): Promise<void> {
    if (this._connected) return;
    if (this.connecting) return this.connecting;
    this.connecting = this.doConnect().finally(() => {
      this.connecting = null;
    });
    return this.connecting;
  }

  private async doConnect(): Promise<void> {
    const stream = await this.openStream();
    this.stream = stream;

    stream.on("data", (d: Buffer | string) => {
      this.acc += typeof d === "string" ? d : d.toString("utf8");
      if (this.waiter) {
        clearTimeout(this.waiter.quiet);
        this.waiter.quiet = setTimeout(() => this.flush(), this.opts.quietMs ?? 150);
      }
    });
    stream.on("error", (e: Error) => log.warn("urc transport stream error", { message: e.message }));
    stream.on("close", () => {
      this._connected = false;
    });

    this._connected = true;
    const hs = this.opts.handshake ?? defaultHandshake;
    try {
      await hs({ token: this.opts.token, term: this.term, send: (f) => this.rawWrite(f), query: (f, ms) => this.collect(f, ms) });
    } catch (err) {
      await this.close();
      throw err;
    }
  }

  private rawWrite(s: string): void {
    if (!this.stream) throw new Error("urc transport not connected");
    this.stream.write(s);
  }

  // Send a frame and accumulate the reply until an idle gap (quietMs) or the
  // hard cap. Overlapping collects are made safe by flushing the prior waiter.
  private collect(frame: string, maxMs?: number): Promise<string> {
    return new Promise<string>((resolve) => {
      if (this.waiter) this.flush();
      this.acc = "";
      this.rawWrite(frame);
      const quiet = setTimeout(() => this.flush(), this.opts.quietMs ?? 150);
      const hard = setTimeout(() => this.flush(), maxMs ?? this.opts.queryTimeoutMs ?? 3000);
      this.waiter = { resolve, quiet, hard };
    });
  }

  private flush(): void {
    const w = this.waiter;
    if (!w) return;
    clearTimeout(w.quiet);
    clearTimeout(w.hard);
    this.waiter = null;
    const out = this.acc;
    this.acc = "";
    w.resolve(out);
  }

  async send(frame: string): Promise<void> {
    if (!this._connected) await this.connect();
    this.rawWrite(frame);
  }

  async query(frame: string): Promise<string> {
    if (!this._connected) await this.connect();
    return this.collect(frame);
  }

  async close(): Promise<void> {
    this._connected = false;
    if (this.waiter) this.flush();
    const s = this.stream;
    this.stream = null;
    if (s) {
      try {
        s.end();
        s.destroy();
      } catch {
        /* ignore */
      }
    }
  }
}

// ---- TCP (IP) — uses node:net, no new dependencies -------------------------

export function createUrcTcpTransport(
  cfg: UrcTransportOptions & { host: string; port: number },
): UrcStreamTransport {
  const open = () =>
    new Promise<Duplex>((resolve, reject) => {
      const sock = net.createConnection({ host: cfg.host, port: cfg.port });
      const to = setTimeout(() => {
        sock.destroy();
        reject(new Error(`URC TCP connect timeout ${cfg.host}:${cfg.port}`));
      }, cfg.connectTimeoutMs ?? 5000);
      sock.once("connect", () => {
        clearTimeout(to);
        resolve(sock);
      });
      sock.once("error", (e) => {
        clearTimeout(to);
        reject(e);
      });
    });
  return new UrcStreamTransport(open, cfg);
}

// ---- Serial — bring-your-own stream (no serialport dependency) -------------
//
// Example (integrator side):
//   import { SerialPort } from "serialport";
//   const t = createUrcSerialTransport(
//     () => new SerialPort({ path: "/dev/tty.usbserial", baudRate: 115200 }),
//     { token: process.env.URC_TOKEN! },
//   );
export function createUrcSerialTransport(
  streamFactory: () => Promise<Duplex> | Duplex,
  cfg: UrcTransportOptions,
): UrcStreamTransport {
  return new UrcStreamTransport(() => streamFactory(), cfg);
}
