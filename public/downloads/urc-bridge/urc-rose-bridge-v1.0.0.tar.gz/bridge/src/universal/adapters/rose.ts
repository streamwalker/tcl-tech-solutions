// =============================================================================
// RoseAdapter — the LIVE reference adapter (device-host only).
// =============================================================================
//
// This is the proof the framework controls real hardware: it wraps the existing
// RoseClient (the reverse-engineered Hi-Fi Rose protocol) unchanged and exposes
// the Rose streamer as ONE canonical media_player entity. Because it is a device
// host, a command originating from Control4, URC, or Josh now lands on the Rose
// — which is exactly the gap the user wants closed.
//
// Capabilities advertised: power, volume, source. Transport is intentionally
// NOT advertised — the Rose transport endpoints are unverified (Phase 2 in the
// implementation plan, /v1/transport returns 501). Advertising a capability we
// cannot honor would be dishonest to controllers.

import { RoseClient } from "../../rose-client.js";
import type { DeviceHost, EcosystemAdapter } from "../adapter.js";
import {
  TranslatorError,
  entityId,
  type CanonicalCommand,
  type CanonicalEntity,
  type CanonicalState,
} from "../model.js";
import { CANONICAL_TO_ROSE_SOURCE, ROSE_SOURCE_TO_CANONICAL, clampLevel } from "../mappings.js";

export interface RoseAdapterOptions {
  host: string;
  port?: number;
  slug?: string; // entity slug; defaults to "rose"
  name?: string;
  room?: string;
  pollIntervalMs?: number;
}

export class RoseAdapter implements EcosystemAdapter {
  readonly ecosystem = "rose" as const;
  readonly id: string;
  device: DeviceHost;

  private client: RoseClient;
  private entity: CanonicalEntity;

  constructor(opts: RoseAdapterOptions) {
    const slug = opts.slug ?? "rose";
    this.id = `rose-${slug}`;
    this.client = new RoseClient({ host: opts.host, port: opts.port });

    this.entity = {
      id: entityId("rose", "media_player", slug),
      type: "media_player",
      name: opts.name ?? "Hi-Fi Rose RS520",
      room: opts.room,
      ecosystem: "rose",
      nativeId: `${opts.host}:${opts.port ?? 9283}`,
      capabilities: ["power", "volume", "source"],
      meta: {
        sources: Object.values(ROSE_SOURCE_TO_CANONICAL),
        note: "transport is Phase 2 (unverified); not advertised",
      },
    };

    const self = this;
    this.device = {
      pollIntervalMs: opts.pollIntervalMs,
      listEntities() {
        return [self.entity];
      },
      async getState() {
        return self.readState();
      },
      async applyCommand(cmd) {
        return self.apply(cmd);
      },
    };
  }

  private async readState(): Promise<CanonicalState> {
    const r = await this.client.getState();
    const source = r.source !== "unknown" ? ROSE_SOURCE_TO_CANONICAL[r.source] ?? null : null;
    return {
      entityId: this.entity.id,
      reachable: true,
      power: r.power,
      volume: { level: r.volume, muted: false }, // Rose telemetry has no mute flag
      source,
      // Read-only play telemetry. We report it for feedback (and /v1 compat) but
      // do NOT advertise the `transport` capability, because Rose transport
      // *control* is unverified (Phase 2).
      transport: { playing: r.playing },
      raw: r.raw,
    };
  }

  private async apply(cmd: CanonicalCommand): Promise<void> {
    switch (cmd.capability) {
      case "power":
        return this.applyPower(cmd);
      case "volume":
        return this.applyVolume(cmd);
      case "source":
        return this.applySource(cmd);
      default:
        throw new TranslatorError("capability_unsupported", `rose: '${cmd.capability}' not handled`);
    }
  }

  private async applyPower(cmd: CanonicalCommand): Promise<void> {
    let target: "on" | "off";
    if (cmd.action === "toggle") {
      const cur = (await this.client.getState()).power;
      target = cur === "on" ? "off" : "on";
    } else {
      const state = cmd.args?.state;
      if (state !== "on" && state !== "off") {
        throw new TranslatorError("bad_args", "power.set requires args.state = on|off");
      }
      target = state;
    }
    if (target === "on") await this.client.powerOn();
    else await this.client.powerOff();
  }

  private async applyVolume(cmd: CanonicalCommand): Promise<void> {
    if (cmd.action === "mute") {
      // Rose's reverse-engineered surface has no mute primitive. Be explicit.
      throw new TranslatorError("not_implemented", "rose: mute not supported by device protocol");
    }
    let target: number;
    if (cmd.action === "step") {
      const delta = Number(cmd.args?.delta);
      if (!Number.isFinite(delta)) throw new TranslatorError("bad_args", "volume.step requires args.delta");
      const cur = (await this.client.getState()).volume;
      if (cur === null) throw new TranslatorError("bad_args", "volume.step: current volume unknown");
      target = cur + delta;
    } else {
      const level = Number(cmd.args?.level);
      if (!Number.isFinite(level)) throw new TranslatorError("bad_args", "volume.set requires args.level");
      target = level;
    }
    await this.client.setVolume(clampLevel(target));
  }

  private async applySource(cmd: CanonicalCommand): Promise<void> {
    const canonical = String(cmd.args?.source ?? "");
    const roseName = CANONICAL_TO_ROSE_SOURCE[canonical];
    if (!roseName) {
      throw new TranslatorError("bad_args", `rose: no input for source '${canonical}'`, {
        accepted: Object.keys(CANONICAL_TO_ROSE_SOURCE),
      });
    }
    // roseName is a validated SourceName key; selectSource expects that union.
    await this.client.selectSource(roseName as Parameters<RoseClient["selectSource"]>[0]);
  }
}
