// =============================================================================
// UrcAdapter — URC Total Control: controller-side (IP driver) + device scaffold.
// =============================================================================
//
// CONTROLLER SIDE: a URC custom IP driver (authored in Accelerator 3) sends
// command strings to the bridge — exactly the role the original /v1 contract
// served. translateInbound accepts those driver functions (PowerOn, VolumeSet,
// Input2, ...) and turns them into canonical commands, so a URC handheld can now
// drive a Control4 light or a Josh-managed device. renderState emits a flat
// key/value object suited to URC "Universal Parse Data" two-way feedback.
//
// DEVICE SIDE: per URC guidance, the supported, low-risk path is a SECURED
// ASCII command channel (IP or serial) via URC's basic SDK — not a C++/Visual
// C++ Accelerator driver. The device host is backed by a token-authenticated
// UrcAsciiTransport plus the ASCII codec in ./urc-ascii.ts (one-way command
// send + optional two-way response parsing). It activates when a transport is
// supplied; otherwise the adapter is controller-only.

import type { ControllerSide, DeviceHost, EcosystemAdapter } from "../adapter.js";
import {
  type Capability,
  type CanonicalCommand,
  type CanonicalEntity,
  type CanonicalState,
  type CommandSource,
} from "../model.js";
import { normalizeSource } from "../mappings.js";
import {
  makeUrcAsciiDeviceHost,
  type UrcAsciiTransport,
  type UrcAsciiCommandMap,
  type UrcParseRule,
} from "./urc-ascii.js";

// Default URC input index -> canonical source. Matches the implementation
// plan's Rose input map; override per installation via the constructor.
const DEFAULT_INPUT_MAP: Record<number, string> = {
  1: "line_in",
  2: "optical",
  3: "earc",
  4: "usb",
  5: "aes_ebu",
};

export interface UrcAdapterOptions {
  id?: string;
  inputMap?: Record<number, string>;
  volumeStep?: number;
  // Device-host (ASCII) options — supply a transport to expose URC-owned
  // devices to the other ecosystems.
  transport?: UrcAsciiTransport;
  entities?: CanonicalEntity[];
  commandMap?: UrcAsciiCommandMap;
  parseRules?: UrcParseRule[];
  pollIntervalMs?: number;
}

export class UrcAdapter implements EcosystemAdapter {
  readonly ecosystem = "urc" as const;
  readonly id: string;
  controller: ControllerSide;
  device?: DeviceHost;

  private inputMap: Record<number, string>;
  private stepSize: number;

  constructor(opts: UrcAdapterOptions = {}) {
    this.id = opts.id ?? "urc-mrx";
    this.inputMap = opts.inputMap ?? DEFAULT_INPUT_MAP;
    this.stepSize = opts.volumeStep ?? 2;

    const self = this;
    this.controller = {
      translateInbound(native) {
        return self.translate(native);
      },
      renderState(_entity, state) {
        return self.render(state);
      },
    };

    if (opts.transport) {
      // Invert the controller's index->canonical map to canonical->index so
      // command encoding and response parsing share one input convention.
      const inputIndex: Record<string, number> = {};
      for (const [idx, src] of Object.entries(this.inputMap)) inputIndex[src] = Number(idx);
      this.device = makeUrcAsciiDeviceHost({
        transport: opts.transport,
        entities: opts.entities ?? [],
        commandMap: opts.commandMap,
        parseRules: opts.parseRules,
        inputIndex,
        pollIntervalMs: opts.pollIntervalMs,
      });
    }
  }

  // ---- controller: URC driver function -> canonical -------------------------

  private translate(native: unknown): CanonicalCommand[] {
    if (!native || typeof native !== "object") return [];
    const o = native as Record<string, unknown>;
    const entityId = typeof o.entityId === "string" ? o.entityId : undefined;
    if (!entityId) return [];
    const source: CommandSource = { ecosystem: "urc", controller: typeof o.room === "string" ? o.room : undefined };

    // Generic relay passthrough.
    if (typeof o.capability === "string" && typeof o.action === "string") {
      return [{ entityId, capability: o.capability as Capability, action: o.action, args: o.args as Record<string, unknown> | undefined, source }];
    }

    const fn = String(o.function ?? o.fn ?? "");
    const partial = this.fromFunction(fn, o);
    return partial ? [{ ...partial, entityId, source }] : [];
  }

  private fromFunction(fn: string, o: Record<string, unknown>): Omit<CanonicalCommand, "entityId" | "source"> | null {
    const inputMatch = fn.match(/^Input(\d+)$/i);
    if (inputMatch) {
      const idx = Number(inputMatch[1]);
      const src = this.inputMap[idx] ?? normalizeSource(String(o.value ?? `input${idx}`));
      return { capability: "source", action: "set", args: { source: src } };
    }
    switch (fn) {
      case "PowerOn":
        return { capability: "power", action: "set", args: { state: "on" } };
      case "PowerOff":
        return { capability: "power", action: "set", args: { state: "off" } };
      case "PowerToggle":
        return { capability: "power", action: "toggle" };
      case "VolumeSet":
        return { capability: "volume", action: "set", args: { level: Number(o.value) } };
      case "VolumeUp":
        return { capability: "volume", action: "step", args: { delta: this.stepSize } };
      case "VolumeDown":
        return { capability: "volume", action: "step", args: { delta: -this.stepSize } };
      case "Mute":
      case "MuteToggle":
        return { capability: "volume", action: "mute" };
      case "Play":
      case "Pause":
      case "Stop":
      case "Next":
      case "Previous":
        return { capability: "transport", action: fn.toLowerCase() };
      default:
        return null;
    }
  }

  // ---- controller: canonical state -> URC Universal Parse Data --------------

  private render(state: CanonicalState): Record<string, unknown> {
    // Flat, uppercase key/values are the easiest shape for a URC parse-data
    // block to extract from a single response.
    const out: Record<string, unknown> = { ONLINE: state.reachable ? 1 : 0 };
    if (state.power !== undefined) out.POWER = state.power === "on" ? "ON" : "OFF";
    if (state.source != null) out.SOURCE = String(state.source).toUpperCase();
    if (state.volume) {
      out.VOLUME = state.volume.level ?? 0;
      out.MUTE = state.volume.muted ? 1 : 0;
    }
    if (state.transport) out.PLAYING = state.transport.playing ? 1 : 0;
    return out;
  }
}
