// =============================================================================
// buildTranslator — assemble the router + adapters from configuration.
// =============================================================================
//
// This is the only place that decides which ecosystems are live. It wires the
// Josh resolver to the registry so spoken room/device names resolve to real
// canonical entities, then returns a started-able router.

import { TranslatorRouter } from "./router.js";
import { RoseAdapter } from "./adapters/rose.js";
import { MockAdapter, demoMockAdapter } from "./adapters/mock.js";
import { Control4Adapter } from "./adapters/control4.js";
import { UrcAdapter } from "./adapters/urc.js";
import { JoshAdapter, type EntityResolver } from "./adapters/josh.js";
import type { CanonicalEntity, EntityType } from "./model.js";

export interface TranslatorConfig {
  rose?: { enabled: boolean; host: string; port: number; pollIntervalMs?: number };
  mockDemo?: boolean;
  controllers?: string[]; // "control4" | "urc" | "josh"
  pollIntervalMs?: number;
}

export function buildTranslator(cfg: TranslatorConfig): TranslatorRouter {
  const router = new TranslatorRouter({ defaultPollIntervalMs: cfg.pollIntervalMs });

  // The resolver Josh (and any NL controller) uses to turn "the kitchen" into
  // entities. Defined over the router's registry so it always reflects live
  // devices from every device-host adapter.
  const resolve: EntityResolver = (q: { room?: string; name?: string; type?: EntityType }) => {
    const all = router.registry.all().map((r) => r.entity);
    const norm = (s?: string) => (s ?? "").trim().toLowerCase();
    let out: CanonicalEntity[] = all;
    if (q.type) out = out.filter((e) => e.type === q.type);
    if (q.room) out = out.filter((e) => norm(e.room).includes(norm(q.room)));
    if (q.name) out = out.filter((e) => norm(e.name).includes(norm(q.name)));
    // Require some target so an unscoped utterance does not fan out to the whole
    // house. (Josh itself always provides a room or device.)
    if (!q.room && !q.name) return [];
    return out;
  };

  // ---- device hosts ---------------------------------------------------------

  if (cfg.rose?.enabled) {
    router.register(
      new RoseAdapter({
        host: cfg.rose.host,
        port: cfg.rose.port,
        room: "Listening Room",
        pollIntervalMs: cfg.rose.pollIntervalMs,
      }),
    );
  }

  if (cfg.mockDemo) {
    router.register(demoMockAdapter());
  }

  // ---- controllers ----------------------------------------------------------

  const controllers = new Set(cfg.controllers ?? []);
  if (controllers.has("control4")) router.register(new Control4Adapter());
  if (controllers.has("urc")) router.register(new UrcAdapter());
  if (controllers.has("josh")) router.register(new JoshAdapter({ resolve }));

  return router;
}

// Re-export the pieces an embedder (tests, the SaaS app) commonly needs.
export { TranslatorRouter, MockAdapter, RoseAdapter, Control4Adapter, UrcAdapter, JoshAdapter };
