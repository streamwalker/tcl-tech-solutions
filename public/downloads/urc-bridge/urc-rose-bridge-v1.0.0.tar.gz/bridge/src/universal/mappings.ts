// =============================================================================
// Vocabulary mappings — native ecosystem terms <-> canonical tokens.
// =============================================================================
//
// Translation is mostly a problem of vocabulary, not transport. Each adapter
// owns its own protocol details, but the *source/input* vocabulary recurs
// across adapters (Rose's "OPTICAL", URC's input index 2, Josh's spoken
// "optical in"), so the shared tables live here. Adapters import what they need.

import type { CanonicalSource } from "./model.js";

// ---- Rose <-> canonical sources --------------------------------------------
//
// The Rose device speaks the 5 physical inputs enumerated in rose-client.ts.
// Map them to the shared canonical tokens so a Control4 or Josh "select optical"
// lands on the right Rose funcMode without either side knowing Rose's integers.

export const ROSE_SOURCE_TO_CANONICAL: Record<string, CanonicalSource> = {
  LINE_IN: "line_in",
  OPTICAL: "optical",
  EARC: "earc",
  USB: "usb",
  AES_EBU: "aes_ebu",
};

export const CANONICAL_TO_ROSE_SOURCE: Record<string, string> = Object.fromEntries(
  Object.entries(ROSE_SOURCE_TO_CANONICAL).map(([rose, canon]) => [canon, rose]),
);

// ---- Generic source normalizer ----------------------------------------------
//
// Best-effort: fold a free-form native input string onto a canonical token.
// Anything we cannot classify is returned lower-cased and trimmed rather than
// dropped — losing an input silently is worse than carrying an unknown one.
const SOURCE_ALIASES: Record<string, CanonicalSource> = {
  "line in": "line_in",
  line_in: "line_in",
  analog: "line_in",
  aux: "line_in",
  opt: "optical",
  optical: "optical",
  "optical in": "optical",
  toslink: "optical",
  coax: "coax",
  coaxial: "coax",
  spdif: "coax",
  earc: "earc",
  arc: "earc",
  hdmi: "hdmi",
  "hdmi arc": "earc",
  usb: "usb",
  "usb dac": "usb",
  aes: "aes_ebu",
  "aes/ebu": "aes_ebu",
  aes_ebu: "aes_ebu",
  bt: "bluetooth",
  bluetooth: "bluetooth",
  airplay: "airplay",
  spotify: "spotify",
  "spotify connect": "spotify",
  roon: "roon",
  tuner: "tuner",
  radio: "tuner",
  streaming: "streaming",
};

export function normalizeSource(native: string): CanonicalSource {
  const key = native.trim().toLowerCase();
  return SOURCE_ALIASES[key] ?? key;
}

// ---- Volume helpers ---------------------------------------------------------

// Clamp + round to the canonical 0..100 integer scale every adapter uses.
export function clampLevel(n: number): number {
  return Math.max(0, Math.min(100, Math.round(n)));
}

// Convert a canonical 0..100 level to an arbitrary device scale (e.g. Control4
// often uses 0..100 already, some AVRs use 0..255 or a dB scale). Kept here so
// adapters share one rounding convention.
export function scaleLevel(canonical0to100: number, deviceMax: number): number {
  return Math.round((clampLevel(canonical0to100) / 100) * deviceMax);
}

export function unscaleLevel(deviceValue: number, deviceMax: number): number {
  if (deviceMax <= 0) return 0;
  return clampLevel((deviceValue / deviceMax) * 100);
}
