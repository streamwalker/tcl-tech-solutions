// =============================================================================
// TranslatorRouter — the hub of the hub-and-spoke. The actual "translator".
// =============================================================================
//
// Responsibilities:
//   1. Hold the set of adapters and the entity registry.
//   2. dispatch(command): validate it, find the device adapter that owns the
//      target entity, and apply it. This is what lets a command that ORIGINATED
//      in one ecosystem land on a device owned by ANOTHER. The router does not
//      care who sent it — only which device owns the target.
//   3. State sync: keep a cache of every device's canonical state (by polling or
//      by adapter push) and emit StateChangeEvent to subscribers so any number
//      of controllers stay in two-way sync.
//
// The router knows zero vendor protocol. All of that is behind the adapters.

import { isDeviceHost, type EcosystemAdapter } from "./adapter.js";
import { EntityRegistry } from "./registry.js";
import {
  capabilitySupportsAction,
  diffState,
  TranslatorError,
  type CanonicalCommand,
  type CanonicalEntity,
  type CanonicalState,
  type StateChangeEvent,
} from "./model.js";
import { log } from "../logger.js";

export interface RouterOptions {
  defaultPollIntervalMs?: number;
}

interface CacheEntry {
  state: CanonicalState;
  at: number;
}

export interface DispatchResult {
  ok: true;
  entityId: string;
  capability: string;
  action: string;
}

type EventListener = (event: StateChangeEvent) => void;

export class TranslatorRouter {
  readonly registry = new EntityRegistry();
  private adapters: EcosystemAdapter[] = [];
  private cache = new Map<string, CacheEntry>();
  private listeners = new Set<EventListener>();
  private timers: ReturnType<typeof setInterval>[] = [];
  private unsubscribes: (() => void)[] = [];
  private readonly defaultPollMs: number;
  private started = false;

  constructor(opts: RouterOptions = {}) {
    this.defaultPollMs = opts.defaultPollIntervalMs ?? 1000;
  }

  register(adapter: EcosystemAdapter): void {
    if (this.started) throw new Error("register adapters before start()");
    this.adapters.push(adapter);
  }

  adapterList(): readonly EcosystemAdapter[] {
    return this.adapters;
  }

  // ---- lifecycle ------------------------------------------------------------

  async start(): Promise<void> {
    if (this.started) return;
    this.started = true;

    for (const adapter of this.adapters) {
      await adapter.init?.();
      if (isDeviceHost(adapter)) await this.loadAndSync(adapter);
    }

    log.info("translator router started", {
      adapters: this.adapters.map((a) => `${a.ecosystem}:${a.id}`),
      entities: this.registry.size,
    });
  }

  async stop(): Promise<void> {
    for (const t of this.timers) clearInterval(t);
    this.timers = [];
    for (const u of this.unsubscribes) {
      try {
        u();
      } catch {
        /* ignore */
      }
    }
    this.unsubscribes = [];
    for (const a of this.adapters) await a.shutdown?.();
    this.started = false;
  }

  private async loadAndSync(adapter: EcosystemAdapter & { device: NonNullable<EcosystemAdapter["device"]> }): Promise<void> {
    const entities = await adapter.device.listEntities();
    this.registry.replaceForAdapter(adapter.id, entities, adapter);

    // Prime the cache once so /v2/state has data immediately.
    for (const entity of entities) {
      void this.refresh(entity, adapter);
    }

    if (adapter.device.subscribe) {
      // Push model — adapter notifies us of changes.
      const unsub = adapter.device.subscribe((entity, state) => this.ingestState(entity, state));
      this.unsubscribes.push(unsub);
    } else {
      // Poll model — one timer per adapter, sweeping its entities.
      const interval = adapter.device.pollIntervalMs ?? this.defaultPollMs;
      const timer = setInterval(() => {
        for (const reg of this.registry.all()) {
          if (reg.adapter.id === adapter.id) void this.refresh(reg.entity, adapter);
        }
      }, interval);
      this.timers.push(timer);
    }
  }

  // ---- command dispatch (the translation core) ------------------------------

  async dispatch(cmd: CanonicalCommand): Promise<DispatchResult> {
    const reg = this.registry.get(cmd.entityId);
    if (!reg) {
      throw new TranslatorError("entity_not_found", `no entity '${cmd.entityId}'`);
    }
    const { entity, adapter } = reg;

    if (!entity.capabilities.includes(cmd.capability)) {
      throw new TranslatorError(
        "capability_unsupported",
        `'${entity.id}' does not support '${cmd.capability}'`,
        { supported: entity.capabilities },
      );
    }
    if (!capabilitySupportsAction(cmd.capability, cmd.action)) {
      throw new TranslatorError(
        "action_unsupported",
        `capability '${cmd.capability}' has no action '${cmd.action}'`,
      );
    }
    if (!isDeviceHost(adapter)) {
      // Registry only ever holds device-owned entities, so this is defensive.
      throw new TranslatorError("adapter_unreachable", `adapter '${adapter.id}' is not a device host`);
    }

    log.info("dispatch", {
      from: cmd.source ? `${cmd.source.ecosystem}${cmd.source.controller ? "/" + cmd.source.controller : ""}` : "direct",
      to: `${entity.ecosystem}:${entity.nativeId}`,
      capability: cmd.capability,
      action: cmd.action,
      args: cmd.args,
    });

    try {
      await adapter.device.applyCommand(cmd, entity);
    } catch (err) {
      if (err instanceof TranslatorError) throw err;
      throw new TranslatorError("adapter_unreachable", (err as Error).message);
    }

    // Snappy feedback: refresh this one entity right away rather than waiting
    // for the next poll tick.
    void this.refresh(entity, adapter);

    return { ok: true, entityId: entity.id, capability: cmd.capability, action: cmd.action };
  }

  // ---- state ----------------------------------------------------------------

  private async refresh(
    entity: CanonicalEntity,
    adapter: EcosystemAdapter & { device: NonNullable<EcosystemAdapter["device"]> },
  ): Promise<void> {
    try {
      const state = await adapter.device.getState(entity);
      this.ingestState(entity, state);
    } catch (err) {
      // Mark unreachable but keep last-known fields, mirroring the original
      // poller's last-known-good behavior.
      const prev = this.cache.get(entity.id)?.state;
      this.ingestState(entity, { ...(prev ?? { entityId: entity.id }), entityId: entity.id, reachable: false });
      log.debug("state refresh failed", { entity: entity.id, message: (err as Error).message });
    }
  }

  private ingestState(entity: CanonicalEntity, state: CanonicalState): void {
    const prev = this.cache.get(entity.id)?.state ?? null;
    const normalized: CanonicalState = { ...state, entityId: entity.id };
    const changed = diffState(prev, normalized);
    this.cache.set(entity.id, { state: normalized, at: Date.now() });
    if (changed.length > 0) {
      this.emit({ type: "state", entityId: entity.id, state: normalized, changed, at: Date.now() });
    }
  }

  getState(entityId: string): CanonicalState | null {
    const hit = this.cache.get(entityId);
    if (!hit) return null;
    return { ...hit.state, ageMs: Date.now() - hit.at };
  }

  // Force a fresh read (used by the API when a caller wants non-cached state).
  async readFresh(entityId: string): Promise<CanonicalState> {
    const reg = this.registry.get(entityId);
    if (!reg) throw new TranslatorError("entity_not_found", `no entity '${entityId}'`);
    if (!isDeviceHost(reg.adapter)) throw new TranslatorError("adapter_unreachable", "not a device host");
    await this.refresh(reg.entity, reg.adapter);
    return this.getState(entityId)!;
  }

  // ---- events ---------------------------------------------------------------

  onEvent(listener: EventListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private emit(event: StateChangeEvent): void {
    for (const l of this.listeners) {
      try {
        l(event);
      } catch (err) {
        log.warn("event listener threw", { message: (err as Error).message });
      }
    }
  }
}
