// =============================================================================
// Canonical device model — the "interlingua" of the universal translator.
// =============================================================================
//
// The original bridge translated exactly one controller (URC) to exactly one
// device protocol (Hi-Fi Rose). That is a 1:1 bridge. To bridge Control4, URC,
// and Josh AI to each other we need an N-way translator, and the only tractable
// way to build N-way translation is hub-and-spoke: every ecosystem translates
// *to and from* a single neutral vocabulary in the middle, instead of writing
// N×(N−1) direct protocol converters.
//
// This file defines that neutral vocabulary:
//   - EntityType   — what a device *is*        (media_player, light, ...)
//   - Capability   — what a device *can do*    (power, volume, source, ...)
//   - CanonicalCommand — a request to do it    (entity + capability + action)
//   - CanonicalState   — normalized read-back  (one shape for every device)
//   - StateChangeEvent — feedback to controllers
//
// Adapters (see ./adapter.ts) are the only code allowed to know a real
// vendor's protocol. Everything past the adapter boundary speaks only the
// types below. That is what lets a Josh AI voice intent drive a Control4 device
// — or a URC keypad drive a Rose streamer — without either side knowing the
// other exists.

// ---- Ecosystems -------------------------------------------------------------

// An "ecosystem" is anything that owns devices and/or issues commands. Rose is
// a device-only ecosystem (it exposes one streamer, it controls nothing).
// Control4 / URC / Josh are full peers: each can act as a controller (issue
// commands) AND as a device host (own devices the others want to reach).
export type EcosystemId = "control4" | "urc" | "josh" | "rose" | "mock";

export const ECOSYSTEM_LABELS: Record<EcosystemId, string> = {
  control4: "Control4",
  urc: "URC Total Control",
  josh: "Josh AI",
  rose: "Hi-Fi Rose",
  mock: "Mock (in-memory)",
};

// ---- Entity types -----------------------------------------------------------

// The canonical device classes. A real device maps to exactly one of these;
// its feature set is described by `capabilities`, not by the type.
export type EntityType =
  | "media_player"
  | "light"
  | "switch"
  | "thermostat"
  | "lock"
  | "shade"
  | "scene"
  | "sensor"
  | "generic";

// ---- Capabilities -----------------------------------------------------------

// A capability is a coherent bundle of actions + state. An entity advertises
// the capabilities it supports; the router refuses commands for capabilities an
// entity does not advertise (see TranslatorError "capability_unsupported").
export type Capability =
  | "power" // on / off / toggle
  | "volume" // set level 0..100, delta, mute
  | "source" // select input (canonical source token)
  | "transport" // play / pause / stop / next / previous
  | "brightness" // 0..100 (lights / shades dimming)
  | "color" // color temp or hue/sat
  | "climate" // setpoint + mode
  | "lock" // lock / unlock
  | "position" // open / close / set 0..100 (shades, garage)
  | "activate"; // fire a scene / one-shot (no state)

// The actions each capability accepts. Adapters validate against this so a
// controller can introspect what is legal before sending.
export const CAPABILITY_ACTIONS: Record<Capability, readonly string[]> = {
  power: ["set", "toggle"],
  volume: ["set", "step", "mute"],
  source: ["set"],
  transport: ["play", "pause", "stop", "next", "previous", "toggle"],
  brightness: ["set", "step"],
  color: ["set"],
  climate: ["set"],
  lock: ["set", "toggle"],
  position: ["set", "open", "close", "stop"],
  activate: ["fire"],
} as const;

export function capabilitySupportsAction(cap: Capability, action: string): boolean {
  return CAPABILITY_ACTIONS[cap]?.includes(action) ?? false;
}

// ---- Entities ---------------------------------------------------------------

// A real device, described in neutral terms. The canonical `id` is what every
// controller and the API use; `ecosystem` + `nativeId` are how the owning
// adapter finds the real thing. `id` convention: "<ecosystem>:<type>:<slug>".
export interface CanonicalEntity {
  id: string;
  type: EntityType;
  name: string;
  room?: string;
  ecosystem: EcosystemId; // where the physical device actually lives
  nativeId: string; // identifier within that ecosystem's protocol
  capabilities: Capability[];
  // Per-capability hints an adapter wants to advertise, e.g. the source list a
  // media_player accepts, or a thermostat's unit. Free-form by design.
  meta?: Record<string, unknown>;
}

export function entityId(ecosystem: EcosystemId, type: EntityType, slug: string): string {
  return `${ecosystem}:${type}:${slug}`;
}

// ---- Canonical source vocabulary --------------------------------------------

// Physical/logical inputs, normalized. Every adapter maps its native input
// names to one of these tokens (see ./mappings.ts). Unknown inputs pass through
// as a lower-cased free string so we never *lose* an input we cannot classify.
export type CanonicalSource =
  | "line_in"
  | "optical"
  | "coax"
  | "earc"
  | "hdmi"
  | "usb"
  | "aes_ebu"
  | "bluetooth"
  | "airplay"
  | "spotify"
  | "roon"
  | "tuner"
  | "streaming"
  | (string & {}); // allow, but keep autocompletion for the known set

// ---- Commands ---------------------------------------------------------------

// Where a command came from. Carried end-to-end for logging, loop-prevention,
// and so a device adapter can decline to echo an event back to its originator.
export interface CommandSource {
  ecosystem: EcosystemId;
  // Free-form controller identity within that ecosystem (keypad id, Josh room,
  // C4 agent, etc.). Used only for tracing.
  controller?: string;
}

// The single shape every controller produces and every device consumes.
export interface CanonicalCommand {
  entityId: string;
  capability: Capability;
  action: string;
  args?: Record<string, unknown>;
  source?: CommandSource;
  // Opaque id for correlating a command with its resulting state event.
  correlationId?: string;
}

// ---- State ------------------------------------------------------------------

export interface NowPlaying {
  title?: string;
  artist?: string;
  album?: string;
  artUrl?: string;
}

export interface VolumeState {
  level: number | null; // 0..100; null when the device reports an unusable value
  muted: boolean;
}

export interface ClimateState {
  mode?: "off" | "heat" | "cool" | "auto";
  current?: number | null;
  setpoint?: number | null;
  units?: "C" | "F";
}

// One normalized snapshot shape for *every* device class. Fields are optional;
// an entity only populates the ones its capabilities cover. This is what
// /v2/state returns and what controllers parse for two-way feedback — the same
// role the Rose `/v1/state` payload played, generalized.
export interface CanonicalState {
  entityId: string;
  reachable: boolean;
  power?: "on" | "off" | "unknown";
  volume?: VolumeState;
  source?: CanonicalSource | null;
  transport?: { playing: boolean; track?: NowPlaying };
  brightness?: number | null;
  color?: { kind: "temp"; mireds: number } | { kind: "hs"; hue: number; sat: number };
  climate?: ClimateState;
  lock?: "locked" | "unlocked" | "unknown";
  position?: number | null; // 0 (closed) .. 100 (open)
  ageMs?: number | null; // staleness of this snapshot
  raw?: unknown; // last native payload, for debugging protocol drift
}

// ---- Events -----------------------------------------------------------------

// Emitted by the router whenever a device's canonical state changes, so any
// number of controllers can keep their UI in sync. This is the N-way
// generalization of the old single-consumer poller feedback.
export interface StateChangeEvent {
  type: "state";
  entityId: string;
  state: CanonicalState;
  changed: (keyof CanonicalState)[];
  at: number;
}

// ---- Errors -----------------------------------------------------------------

export type TranslatorErrorCode =
  | "entity_not_found"
  | "capability_unsupported"
  | "action_unsupported"
  | "bad_args"
  | "adapter_unreachable"
  | "not_implemented";

// Carries an HTTP-friendly status so the API layer can map errors without a
// second translation table.
export class TranslatorError extends Error {
  readonly code: TranslatorErrorCode;
  readonly httpStatus: number;
  readonly details?: unknown;

  constructor(code: TranslatorErrorCode, message: string, details?: unknown) {
    super(message);
    this.name = "TranslatorError";
    this.code = code;
    this.details = details;
    this.httpStatus = TranslatorError.statusFor(code);
  }

  static statusFor(code: TranslatorErrorCode): number {
    switch (code) {
      case "entity_not_found":
        return 404;
      case "capability_unsupported":
      case "action_unsupported":
      case "bad_args":
        return 400;
      case "adapter_unreachable":
        return 502;
      case "not_implemented":
        return 501;
    }
  }

  toJSON(): { ok: false; error: TranslatorErrorCode; message: string; details?: unknown } {
    return { ok: false, error: this.code, message: this.message, details: this.details };
  }
}

// ---- Diff helper (used by the router to compute `changed`) ------------------

const STATE_KEYS: (keyof CanonicalState)[] = [
  "reachable",
  "power",
  "volume",
  "source",
  "transport",
  "brightness",
  "color",
  "climate",
  "lock",
  "position",
];

// Shallow-but-structural diff: returns the canonical fields that differ between
// two snapshots. JSON comparison is sufficient here — state values are small,
// plain data, and we want value equality (e.g. {level:35,muted:false}).
export function diffState(prev: CanonicalState | null, next: CanonicalState): (keyof CanonicalState)[] {
  if (!prev) return STATE_KEYS.filter((k) => next[k] !== undefined);
  const changed: (keyof CanonicalState)[] = [];
  for (const k of STATE_KEYS) {
    if (JSON.stringify(prev[k]) !== JSON.stringify(next[k])) changed.push(k);
  }
  return changed;
}
