// Subnet discovery for the Hi-Fi Rose RS520.
//
// Strategy: enumerate this host's non-loopback IPv4 interfaces, derive their /24
// subnets, and POST {} to http://<ip>:9283/get_current_state with a short
// timeout. Anything that returns a JSON body containing a "data" field with the
// Rose telemetry shape is an RS520.
//
// We deliberately do NOT use ARP scanning, mDNS, or SSDP — Rose does not
// reliably advertise itself on those channels. The HTTP fingerprint is the
// authoritative test.

import os from "node:os";
import { log } from "./logger.js";

export interface Candidate {
  ip: string;
  ok: boolean;
  matched: boolean;     // looked like an RS520
  status?: number;
  error?: string;
  sample?: unknown;     // small slice of the response, for the report
}

const ROSE_PORT_DEFAULT = 9283;
const PER_HOST_TIMEOUT_MS = 800;
const CONCURRENCY = 64;

// ---- subnet enumeration -----------------------------------------------------

function localSubnets(): string[] {
  const out = new Set<string>();
  const ifaces = os.networkInterfaces();
  for (const list of Object.values(ifaces)) {
    if (!list) continue;
    for (const ni of list) {
      if (ni.family !== "IPv4") continue;
      if (ni.internal) continue;
      // Only /24 scans for now; /16 would be 65k probes.
      const prefix = ni.address.split(".").slice(0, 3).join(".");
      out.add(prefix);
    }
  }
  return [...out];
}

function* subnetIps(prefix: string): Generator<string> {
  for (let i = 1; i <= 254; i++) yield `${prefix}.${i}`;
}

// ---- single-host probe ------------------------------------------------------

async function probeHost(ip: string, port: number): Promise<Candidate> {
  const ctrl = new AbortController();
  const to = setTimeout(() => ctrl.abort(), PER_HOST_TIMEOUT_MS);
  try {
    const res = await fetch(`http://${ip}:${port}/get_current_state`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
      signal: ctrl.signal,
    });
    const text = await res.text();
    let parsed: unknown;
    try { parsed = JSON.parse(text); } catch { parsed = text; }

    // Fingerprint: Rose's /get_current_state wraps payload in { data: { ... } }
    // with at least one of isPowerOn / isPlaying / tempArr / volume.
    const matched = looksLikeRose(parsed);

    return {
      ip,
      ok: res.ok,
      matched,
      status: res.status,
      sample: matched ? sample(parsed) : undefined,
    };
  } catch (err) {
    return {
      ip,
      ok: false,
      matched: false,
      error: (err as Error).name === "AbortError" ? "timeout" : (err as Error).message,
    };
  } finally {
    clearTimeout(to);
  }
}

function looksLikeRose(payload: unknown): boolean {
  if (!payload || typeof payload !== "object") return false;
  const data = (payload as { data?: unknown }).data;
  if (!data || typeof data !== "object") return false;
  const d = data as Record<string, unknown>;
  return (
    "isPowerOn" in d ||
    "isPlaying" in d ||
    "tempArr" in d ||
    "volume" in d
  );
}

function sample(payload: unknown): unknown {
  // Trim the payload so the report file doesn't balloon.
  if (!payload || typeof payload !== "object") return payload;
  const data = (payload as { data?: unknown }).data;
  if (!data || typeof data !== "object") return payload;
  const d = data as Record<string, unknown>;
  return {
    isPowerOn: d["isPowerOn"],
    isPlaying: d["isPlaying"],
    volume: d["volume"],
    tempArr: Array.isArray(d["tempArr"]) ? (d["tempArr"] as unknown[]).slice(0, 6) : undefined,
  };
}

// ---- bounded-concurrency map ------------------------------------------------

async function mapLimited<T, R>(
  items: T[],
  limit: number,
  fn: (t: T) => Promise<R>,
): Promise<R[]> {
  const results: R[] = new Array(items.length);
  let idx = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (true) {
      const i = idx++;
      if (i >= items.length) return;
      results[i] = await fn(items[i]!);
    }
  });
  await Promise.all(workers);
  return results;
}

// ---- public entrypoint ------------------------------------------------------

export interface DiscoveryResult {
  subnetsScanned: string[];
  matches: Candidate[];   // candidates that look like an RS520
  errors: Candidate[];    // hosts that errored but we don't care about
  ok: Candidate[];        // hosts that returned 200 but weren't Rose
  durationMs: number;
}

export async function discoverRose(port: number = ROSE_PORT_DEFAULT): Promise<DiscoveryResult> {
  const start = Date.now();
  const subnets = localSubnets();
  log.info("Discovery starting", { subnets, port });

  const ips: string[] = [];
  for (const prefix of subnets) for (const ip of subnetIps(prefix)) ips.push(ip);

  const results = await mapLimited(ips, CONCURRENCY, (ip) => probeHost(ip, port));
  const matches = results.filter((r) => r.matched);
  const ok = results.filter((r) => r.ok && !r.matched);
  const errors = results.filter((r) => !r.ok && r.error && r.error !== "timeout");

  log.info("Discovery complete", {
    matched: matches.length,
    other_ok: ok.length,
    errors: errors.length,
    durationMs: Date.now() - start,
  });

  return {
    subnetsScanned: subnets,
    matches,
    ok,
    errors,
    durationMs: Date.now() - start,
  };
}
