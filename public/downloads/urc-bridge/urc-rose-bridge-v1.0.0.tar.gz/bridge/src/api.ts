// HTTP route definitions — the stable /v1/* contract from the implementation
// plan, served by Fastify. URC will read/write these endpoints; in Phase 4
// Josh AI hits the same surface.

import type { FastifyInstance } from "fastify";
import { RoseClient, isSourceName, type SourceName } from "./rose-client.js";
import type { StatePoller } from "./poller.js";
import type { BridgeConfig } from "./config.js";
import { log } from "./logger.js";

interface Deps {
  client: RoseClient;
  poller: StatePoller;
  config: BridgeConfig;
  startedAt: number;
}

interface PowerBody { state?: "on" | "off" | "toggle" }
interface SourceBody { input?: string }
interface VolumeBody { level?: number; delta?: number }
interface TransportBody { cmd?: string }

export async function registerRoutes(app: FastifyInstance, deps: Deps): Promise<void> {
  const { client, poller, config, startedAt } = deps;

  // ---- health -------------------------------------------------------------
  app.get("/v1/health", async (_req, reply) => {
    const snap = poller.current();
    const reachable = snap.lastOkAt !== null && snap.consecutiveFailures < 3;
    const status = reachable ? 200 : 503;
    return reply.code(status).send({
      ok: reachable,
      bridge: {
        uptimeSec: Math.floor((Date.now() - startedAt) / 1000),
        version: "0.1.0",
      },
      rose: {
        host: client.host,
        port: client.port,
        firmwarePin: config.roseFirmwarePin,
        lastOkAt: snap.lastOkAt,
        lastErrorAt: snap.lastErrorAt,
        consecutiveFailures: snap.consecutiveFailures,
      },
    });
  });

  // ---- state --------------------------------------------------------------
  app.get("/v1/state", async (_req, reply) => {
    const snap = poller.current();
    if (!snap.state) {
      return reply.code(503).send({ ok: false, error: "no_state_yet", details: snap.lastError });
    }
    const ageMs = snap.lastOkAt ? Date.now() - snap.lastOkAt : null;
    return reply.send({
      ok: true,
      power: snap.state.power,
      source: snap.state.source,
      volume: snap.state.volume,
      playing: snap.state.playing,
      ageMs,
    });
  });

  // ---- power --------------------------------------------------------------
  app.post<{ Body: PowerBody }>("/v1/power", async (req, reply) => {
    const desired = req.body?.state;
    if (desired !== "on" && desired !== "off" && desired !== "toggle") {
      return reply.code(400).send({ ok: false, error: "expected state: on | off | toggle" });
    }
    try {
      let effective: "on" | "off";
      if (desired === "toggle") {
        const current = poller.current().state?.power;
        effective = current === "on" ? "off" : "on";
      } else {
        effective = desired;
      }
      if (effective === "on") await client.powerOn();
      else await client.powerOff();
      log.info("power", { requested: desired, applied: effective });
      return reply.send({ ok: true, applied: effective });
    } catch (err) {
      return roseFail(reply, err);
    }
  });

  // ---- source -------------------------------------------------------------
  app.post<{ Body: SourceBody }>("/v1/source", async (req, reply) => {
    const input = req.body?.input;
    if (!input || typeof input !== "string" || !isSourceName(input)) {
      return reply.code(400).send({
        ok: false,
        error: "unknown input",
        accepted: ["LINE_IN", "OPTICAL", "EARC", "USB", "AES_EBU"],
      });
    }
    try {
      await client.selectSource(input as SourceName);
      log.info("source", { input });
      return reply.send({ ok: true, applied: input });
    } catch (err) {
      return roseFail(reply, err);
    }
  });

  // ---- volume -------------------------------------------------------------
  app.post<{ Body: VolumeBody }>("/v1/volume", async (req, reply) => {
    const body = req.body ?? {};
    let target: number;

    if (typeof body.level === "number") {
      target = body.level;
    } else if (typeof body.delta === "number") {
      const cur = poller.current().state?.volume;
      if (cur === null || cur === undefined) {
        return reply.code(409).send({
          ok: false,
          error: "cannot apply delta: current volume unknown",
        });
      }
      target = cur + body.delta;
    } else {
      return reply.code(400).send({ ok: false, error: "expected level (0-100) or delta" });
    }

    target = Math.max(0, Math.min(100, Math.round(target)));
    try {
      await client.setVolume(target);
      log.info("volume", { applied: target });
      return reply.send({ ok: true, applied: target });
    } catch (err) {
      return roseFail(reply, err);
    }
  });

  // ---- transport (Phase 2 placeholder) ------------------------------------
  // The Rose HTTP transport API surface is not yet captured for the streaming
  // (Roon/Spotify/AirPlay) sources. This endpoint exists so the URC driver
  // can be wired today and the bridge can be filled in later without changing
  // the contract.
  app.post<{ Body: TransportBody }>("/v1/transport", async (req, reply) => {
    const cmd = req.body?.cmd;
    if (!cmd) return reply.code(400).send({ ok: false, error: "expected cmd" });
    return reply.code(501).send({
      ok: false,
      error: "not implemented",
      note: "Transport commands require Phase 2 endpoint capture. See implementation plan §6 Phase 2.",
      requested: cmd,
    });
  });

  // ---- root ---------------------------------------------------------------
  app.get("/", async (_req, reply) => {
    return reply.send({
      service: "urc-rose-bridge",
      version: "0.1.0",
      routes: [
        "GET  /v1/health",
        "GET  /v1/state",
        "POST /v1/power     {state: on|off|toggle}",
        "POST /v1/source    {input: LINE_IN|OPTICAL|EARC|USB|AES_EBU}",
        "POST /v1/volume    {level: 0-100} or {delta: ±n}",
        "POST /v1/transport {cmd: play|pause|...}  (Phase 2)",
      ],
    });
  });
}

function roseFail(reply: import("fastify").FastifyReply, err: unknown) {
  const message = (err as Error).message;
  log.warn("rose call failed", { message });
  return reply.code(502).send({ ok: false, error: "rose_unreachable", details: message });
}
