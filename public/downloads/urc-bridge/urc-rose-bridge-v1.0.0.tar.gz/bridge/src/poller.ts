// State poller — maintains the cached RoseState the bridge serves on /v1/state.
//
// URC reads /v1/state at whatever cadence its driver schedules; we don't want
// to pass that traffic straight through to the Rose. The poller decouples the
// two: it hits the Rose at POLL_INTERVAL_MS and exposes the latest snapshot
// plus a "last_seen" age.

import { RoseClient, type RoseState } from "./rose-client.js";
import { log } from "./logger.js";

export interface SnapshotMeta {
  state: RoseState | null;
  lastOkAt: number | null;   // epoch ms of last successful poll
  lastErrorAt: number | null;
  lastError: string | null;
  consecutiveFailures: number;
}

export class StatePoller {
  private timer: ReturnType<typeof setTimeout> | null = null;
  private stopped = false;
  private inFlight = false;
  private snapshot: SnapshotMeta = {
    state: null,
    lastOkAt: null,
    lastErrorAt: null,
    lastError: null,
    consecutiveFailures: 0,
  };

  constructor(
    private readonly client: RoseClient,
    private readonly intervalMs: number,
  ) {}

  start(): void {
    this.stopped = false;
    // Fire-and-schedule; first tick is immediate.
    this.tick().catch(() => undefined);
  }

  stop(): void {
    this.stopped = true;
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
  }

  current(): SnapshotMeta {
    // Return a shallow copy so callers can't mutate internal state.
    return { ...this.snapshot, state: this.snapshot.state ? { ...this.snapshot.state } : null };
  }

  private async tick(): Promise<void> {
    if (this.stopped) return;
    if (this.inFlight) {
      this.schedule();
      return;
    }
    this.inFlight = true;
    try {
      const state = await this.client.getState();
      // Volume holds last-known-good: if Rose returned null, keep the previous value.
      const previousVol = this.snapshot.state?.volume ?? null;
      const merged: RoseState = {
        ...state,
        volume: state.volume ?? previousVol,
      };
      this.snapshot = {
        state: merged,
        lastOkAt: Date.now(),
        lastErrorAt: this.snapshot.lastErrorAt,
        lastError: this.snapshot.lastError,
        consecutiveFailures: 0,
      };
      log.debug("poll ok", merged);
    } catch (err) {
      this.snapshot = {
        ...this.snapshot,
        lastErrorAt: Date.now(),
        lastError: (err as Error).message,
        consecutiveFailures: this.snapshot.consecutiveFailures + 1,
      };
      // Backoff logging: warn on the first failure, then quiet down.
      if (this.snapshot.consecutiveFailures === 1) {
        log.warn("Rose poll failed (will retry)", { message: (err as Error).message });
      }
    } finally {
      this.inFlight = false;
      this.schedule();
    }
  }

  private schedule(): void {
    if (this.stopped) return;
    // Exponential-ish backoff while failing, capped.
    const failures = this.snapshot.consecutiveFailures;
    const ms = failures > 0
      ? Math.min(this.intervalMs * 2 ** Math.min(failures, 5), 30_000)
      : this.intervalMs;
    this.timer = setTimeout(() => this.tick().catch(() => undefined), ms);
  }
}
