// Bridge service entrypoint.
// Starts the universal translator (router + adapters) and the Fastify HTTP
// server, mounting both the /v2 universal surface and the /v1 Rose-compat shim.
//
// Run dev:        npm run dev
// Build & run:    npm run build && npm start
// Docker:         docker compose up --build

import Fastify from "fastify";
import { loadConfig } from "./config.js";
import { discoverRose } from "./rose-discover.js";
import { log, setLogLevel } from "./logger.js";
import { buildTranslator } from "./universal/translator.js";
import { registerUniversalRoutes } from "./universal/api.js";
import { registerV1Shim } from "./universal/v1-shim.js";

async function resolveRoseHost(): Promise<{ host: string; port: number }> {
  const cfg = loadConfig();
  if (cfg.roseDiscovery) {
    log.info("ROSE_DISCOVERY=true → scanning subnet on startup");
    const result = await discoverRose(cfg.rosePort);
    const first = result.matches[0];
    if (first) {
      log.info(`Discovery found RS520 at ${first.ip}`);
      return { host: first.ip, port: cfg.rosePort };
    }
    log.warn(`Discovery found no RS520; falling back to ROSE_HOST=${cfg.roseHost}`);
  }
  return { host: cfg.roseHost, port: cfg.rosePort };
}

async function main(): Promise<void> {
  const cfg = loadConfig();
  if (process.env.LOG_LEVEL) setLogLevel(process.env.LOG_LEVEL as "info");

  log.info("Starting universal-translator bridge", { version: "0.2.0", cfg: { ...cfg } });

  const rose = cfg.utRoseEnabled ? await resolveRoseHost() : null;

  const router = buildTranslator({
    rose: rose ? { enabled: true, host: rose.host, port: rose.port, pollIntervalMs: cfg.pollIntervalMs } : undefined,
    mockDemo: cfg.utMockDemo,
    controllers: cfg.utControllers,
    pollIntervalMs: cfg.pollIntervalMs,
  });
  await router.start();

  const startedAt = Date.now();
  const app = Fastify({ logger: false, bodyLimit: 16 * 1024 });

  app.get("/", async (_req, reply) =>
    reply.send({
      service: "universal-translator",
      version: "0.2.0",
      surfaces: { v1: cfg.utRoseEnabled ? "/v1/* (Rose-compat)" : "disabled", v2: cfg.utEnabled ? "/v2/*" : "disabled" },
    }),
  );

  if (cfg.utEnabled) await registerUniversalRoutes(app, { router, startedAt });
  if (cfg.utRoseEnabled) registerV1Shim(app, { router, config: cfg, startedAt });

  const shutdown = async (signal: string) => {
    log.info(`Received ${signal}; shutting down`);
    await router.stop();
    try {
      await app.close();
    } catch {
      /* ignore */
    }
    process.exit(0);
  };
  process.on("SIGINT", () => void shutdown("SIGINT"));
  process.on("SIGTERM", () => void shutdown("SIGTERM"));

  try {
    await app.listen({ host: cfg.bridgeHost, port: cfg.bridgePort });
    log.info(`Bridge listening on http://${cfg.bridgeHost}:${cfg.bridgePort}`);
    if (rose) log.info(`Rose target:        http://${rose.host}:${rose.port}`);
    log.info(`Entities online:    ${router.registry.size}`);
  } catch (err) {
    log.error("Bridge failed to start", { message: (err as Error).message });
    process.exit(1);
  }
}

main().catch((err) => {
  log.error("Bridge crashed at startup", { message: (err as Error).message, stack: (err as Error).stack });
  process.exit(1);
});
