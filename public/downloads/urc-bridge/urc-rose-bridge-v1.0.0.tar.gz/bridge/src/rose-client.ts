// RoseClient — typed wrapper around the reverse-engineered Hi-Fi Rose RS520
// HTTP/JSON control surface on port 9283.
//
// Endpoint signatures captured from packet inspection of the Rose Connect PC
// application, cross-validated against the community Home Assistant integration
// (github.com/cornusmas87/hifirose_rs520) on RS520 firmware 5.9.02.
//
// WARNING: This API is NOT publicly documented. Hi-Fi Rose has reshaped these
// endpoints across firmware releases. If a firmware update breaks control,
// re-capture the PC app's traffic and update SOURCE_TO_FUNC_MODE,
// power/volume/source endpoints below.

import { log } from "./logger.js";

// ---- Input source enumeration ------------------------------------------------
// funcMode integer values observed in the Rose HTTP API.
export const SOURCE_TO_FUNC_MODE = {
  LINE_IN: 1,
  OPTICAL: 2,
  EARC: 3,
  USB: 4,
  AES_EBU: 5,
} as const;

export type SourceName = keyof typeof SOURCE_TO_FUNC_MODE;
export type FuncMode = (typeof SOURCE_TO_FUNC_MODE)[SourceName];

export const FUNC_MODE_TO_SOURCE: Record<number, SourceName> = Object.fromEntries(
  Object.entries(SOURCE_TO_FUNC_MODE).map(([k, v]) => [v, k as SourceName]),
) as Record<number, SourceName>;

export function isSourceName(s: string): s is SourceName {
  return Object.prototype.hasOwnProperty.call(SOURCE_TO_FUNC_MODE, s);
}

// ---- Public state shape (what the bridge exposes) ---------------------------
export interface RoseState {
  power: "on" | "off" | "unknown";
  source: SourceName | "unknown";
  volume: number | null; // 0..100; null when telemetry returned 0/invalid
  playing: boolean;
  raw: unknown; // last raw payload, useful for debugging firmware drift
}

// ---- Raw response shape (best-effort; Rose is loose with types) -------------
interface CurrentStateData {
  volume?: number | string;
  tempArr?: string[];
  isPlaying?: boolean;
  isPowerOn?: boolean;
  [k: string]: unknown;
}

interface CurrentStateResponse {
  data?: CurrentStateData;
  [k: string]: unknown;
}

// ---- Client -----------------------------------------------------------------

export interface RoseClientOptions {
  host: string;
  port?: number;
  timeoutMs?: number;
}

export class RoseClient {
  readonly host: string;
  readonly port: number;
  readonly timeoutMs: number;

  constructor(opts: RoseClientOptions) {
    this.host = opts.host;
    this.port = opts.port ?? 9283;
    this.timeoutMs = opts.timeoutMs ?? 5000;
  }

  get baseUrl(): string {
    return `http://${this.host}:${this.port}`;
  }

  // ---- low-level POST -------------------------------------------------------
  private async post<T = unknown>(path: string, body: unknown): Promise<T> {
    const ctrl = new AbortController();
    const to = setTimeout(() => ctrl.abort(), this.timeoutMs);
    try {
      const res = await fetch(`${this.baseUrl}${path}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
        signal: ctrl.signal,
      });
      if (!res.ok) {
        throw new Error(`Rose POST ${path} -> HTTP ${res.status}`);
      }
      // Rose sometimes returns empty bodies on writes; tolerate that.
      const text = await res.text();
      if (!text) return {} as T;
      try {
        return JSON.parse(text) as T;
      } catch {
        log.warn("Rose returned non-JSON body", { path, text: text.slice(0, 200) });
        return {} as T;
      }
    } finally {
      clearTimeout(to);
    }
  }

  // ---- power ----------------------------------------------------------------
  async powerOn(): Promise<void> {
    await this.post("/remote_bar_order", {
      barControl: "remote_bar_order_sleep_on_off",
      value: "1",
    });
  }

  async powerOff(): Promise<void> {
    await this.post("/remote_bar_order", {
      barControl: "remote_bar_order_sleep_on_off",
      value: "-1",
    });
  }

  // ---- volume ---------------------------------------------------------------
  async setVolume(level: number): Promise<void> {
    const clamped = Math.max(0, Math.min(100, Math.round(level)));
    await this.post("/volume", {
      volumeType: "volume_set",
      volumeValue: clamped,
    });
  }

  // ---- source ---------------------------------------------------------------
  async selectSource(source: SourceName): Promise<void> {
    const funcMode = SOURCE_TO_FUNC_MODE[source];
    await this.post("/input.mode.set", { funcMode });
  }

  // ---- state ----------------------------------------------------------------
  async getState(): Promise<RoseState> {
    const raw = await this.post<CurrentStateResponse>("/get_current_state", {});
    return parseState(raw);
  }

  // ---- raw passthrough (useful for the probe) -------------------------------
  async rawPost(path: string, body: unknown): Promise<unknown> {
    return this.post(path, body);
  }
}

// ---- Pure parser, exported for unit reuse -----------------------------------
export function parseState(raw: CurrentStateResponse | unknown): RoseState {
  const data: CurrentStateData =
    (raw as CurrentStateResponse | undefined)?.data ?? {};

  // Volume: Rose returns 0 in some states (apparently when standby or muted).
  // Treat 0 as "unknown" rather than overwriting a known value upstream.
  let volume: number | null = null;
  const v = data.volume;
  if (typeof v === "number" && v > 0) volume = Math.round(v);
  else if (typeof v === "string") {
    const parsed = Number.parseInt(v, 10);
    if (Number.isFinite(parsed) && parsed > 0) volume = parsed;
  }

  // funcMode is embedded as a string entry in tempArr, e.g. "funcMode:3"
  let source: SourceName | "unknown" = "unknown";
  if (Array.isArray(data.tempArr)) {
    for (const entry of data.tempArr) {
      if (typeof entry !== "string") continue;
      if (entry.startsWith("funcMode:")) {
        const n = Number.parseInt(entry.split(":")[1] ?? "", 10);
        if (Number.isFinite(n) && FUNC_MODE_TO_SOURCE[n]) {
          source = FUNC_MODE_TO_SOURCE[n];
        }
        break;
      }
    }
  }

  // Power: isPowerOn is authoritative when present; isPlaying implies on.
  let power: RoseState["power"] = "unknown";
  if (typeof data.isPowerOn === "boolean") power = data.isPowerOn ? "on" : "off";
  else if (data.isPlaying === true) power = "on";

  return {
    power,
    source,
    volume,
    playing: data.isPlaying === true,
    raw,
  };
}
