// Phase 0 discovery probe.
//
// 1. Scan the local /24 for anything responding like a Hi-Fi Rose RS520.
// 2. For each match, exercise every endpoint the bridge will rely on (READ
//    endpoints only — no power/source/volume changes unless --write is set).
// 3. Emit a JSON report and a human-readable summary.
//
// Usage:
//   npm run probe                       # scan, READ-only
//   npm run probe -- --host 192.168.1.50
//   npm run probe -- --host 192.168.1.50 --write   # exercises writes too
//
// The report is written to ./probe-report-<timestamp>.json so it can be
// committed alongside the code as proof of working firmware.

import fs from "node:fs/promises";
import path from "node:path";
import { discoverRose } from "./rose-discover.js";
import { RoseClient, parseState, SOURCE_TO_FUNC_MODE } from "./rose-client.js";
import { log, setLogLevel } from "./logger.js";

interface Args {
  host?: string;
  port: number;
  write: boolean;
}

function parseArgs(argv: string[]): Args {
  const args: Args = { port: 9283, write: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--host") args.host = argv[++i];
    else if (a === "--port") args.port = Number.parseInt(argv[++i] ?? "9283", 10);
    else if (a === "--write") args.write = true;
    else if (a === "--debug") setLogLevel("debug");
  }
  return args;
}

interface EndpointResult {
  name: string;
  path: string;
  body: unknown;
  ok: boolean;
  durationMs: number;
  response?: unknown;
  error?: string;
}

async function exercise(client: RoseClient, write: boolean): Promise<EndpointResult[]> {
  const results: EndpointResult[] = [];

  // Read first; always safe.
  await run(results, "get_current_state", "/get_current_state", {}, async () =>
    client.rawPost("/get_current_state", {}),
  );

  if (!write) {
    log.info("Skipping write endpoints (pass --write to exercise them).");
    return results;
  }

  // Capture current state so we can restore after the write probes.
  const before = parseState(results[0]?.response);
  log.info("Captured baseline state for restore", before);

  // Power: cycle to opposite, then restore.
  await run(results, "power_off", "/remote_bar_order", { barControl: "remote_bar_order_sleep_on_off", value: "-1" }, async () =>
    client.rawPost("/remote_bar_order", { barControl: "remote_bar_order_sleep_on_off", value: "-1" }),
  );
  await sleep(2500);
  await run(results, "power_on", "/remote_bar_order", { barControl: "remote_bar_order_sleep_on_off", value: "1" }, async () =>
    client.rawPost("/remote_bar_order", { barControl: "remote_bar_order_sleep_on_off", value: "1" }),
  );
  await sleep(4000); // Rose boot lag

  // Volume: read current, set +1, set back.
  const startVol = before.volume ?? 20;
  await run(results, "volume_set_lower", "/volume", { volumeType: "volume_set", volumeValue: Math.max(0, startVol - 1) }, async () =>
    client.rawPost("/volume", { volumeType: "volume_set", volumeValue: Math.max(0, startVol - 1) }),
  );
  await sleep(400);
  await run(results, "volume_restore", "/volume", { volumeType: "volume_set", volumeValue: startVol }, async () =>
    client.rawPost("/volume", { volumeType: "volume_set", volumeValue: startVol }),
  );

  // Source: rotate to LINE_IN then restore.
  const restoreSource = before.source !== "unknown" ? before.source : "LINE_IN";
  await run(results, "source_line_in", "/input.mode.set", { funcMode: SOURCE_TO_FUNC_MODE.LINE_IN }, async () =>
    client.rawPost("/input.mode.set", { funcMode: SOURCE_TO_FUNC_MODE.LINE_IN }),
  );
  await sleep(800);
  await run(results, "source_restore", "/input.mode.set", { funcMode: SOURCE_TO_FUNC_MODE[restoreSource as keyof typeof SOURCE_TO_FUNC_MODE] }, async () =>
    client.rawPost("/input.mode.set", { funcMode: SOURCE_TO_FUNC_MODE[restoreSource as keyof typeof SOURCE_TO_FUNC_MODE] }),
  );

  // Final read.
  await run(results, "get_current_state_after", "/get_current_state", {}, async () =>
    client.rawPost("/get_current_state", {}),
  );

  return results;
}

async function run(
  acc: EndpointResult[],
  name: string,
  endpointPath: string,
  body: unknown,
  fn: () => Promise<unknown>,
): Promise<void> {
  const start = Date.now();
  try {
    const response = await fn();
    const durationMs = Date.now() - start;
    acc.push({ name, path: endpointPath, body, ok: true, durationMs, response });
    log.info(`  ✓ ${name} (${durationMs}ms)`);
  } catch (err) {
    const durationMs = Date.now() - start;
    const error = (err as Error).message;
    acc.push({ name, path: endpointPath, body, ok: false, durationMs, error });
    log.warn(`  ✗ ${name} (${durationMs}ms): ${error}`);
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

async function main(): Promise<void> {
  const args = parseArgs(process.argv.slice(2));

  let target = args.host;
  let discovery: unknown = undefined;

  if (!target) {
    log.info("No --host given; scanning local subnet for RS520…");
    const result = await discoverRose(args.port);
    discovery = result;
    if (result.matches.length === 0) {
      log.error("No RS520 found on local subnet.");
      log.error("Tips: confirm RS520 is powered on, on the same VLAN, and port " + args.port + " is open.");
      process.exitCode = 2;
      return;
    }
    if (result.matches.length > 1) {
      log.warn(`Multiple Rose-like devices found; probing the first one (${result.matches[0]?.ip}).`);
    }
    target = result.matches[0]?.ip;
  }

  if (!target) {
    log.error("No target IP resolved. Aborting.");
    process.exitCode = 2;
    return;
  }

  log.info(`Probing RS520 at ${target}:${args.port}…`);
  const client = new RoseClient({ host: target, port: args.port });
  const endpoints = await exercise(client, args.write);
  const finalState = parseState(endpoints.find((e) => e.name.startsWith("get_current_state"))?.response);

  const report = {
    schemaVersion: 1,
    generatedAt: new Date().toISOString(),
    target: { host: target, port: args.port },
    discovery,
    endpoints,
    parsedState: finalState,
    inputMap: SOURCE_TO_FUNC_MODE,
  };

  const outfile = path.resolve(process.cwd(), `probe-report-${Date.now()}.json`);
  await fs.writeFile(outfile, JSON.stringify(report, null, 2));
  log.info(`Report written: ${outfile}`);

  const failed = endpoints.filter((e) => !e.ok);
  if (failed.length > 0) {
    log.error(`${failed.length} endpoint(s) failed. See report.`);
    process.exitCode = 1;
  } else {
    log.info(`All ${endpoints.length} endpoint(s) succeeded.`);
    log.info(`Parsed state: power=${finalState.power}, source=${finalState.source}, volume=${finalState.volume ?? "unknown"}`);
  }
}

main().catch((err) => {
  log.error("Probe crashed", { message: (err as Error).message, stack: (err as Error).stack });
  process.exitCode = 3;
});
