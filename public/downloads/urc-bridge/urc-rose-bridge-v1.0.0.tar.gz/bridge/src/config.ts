// Centralized env config. Read once at startup; never reach into process.env from
// anywhere else.

export interface BridgeConfig {
  roseHost: string;
  rosePort: number;
  roseDiscovery: boolean;
  roseFirmwarePin: string;
  bridgeHost: string;
  bridgePort: number;
  pollIntervalMs: number;
  // --- universal translator ---
  utEnabled: boolean; // mount the /v2 universal translator surface
  utRoseEnabled: boolean; // include the Rose device as a live canonical entity
  utMockDemo: boolean; // register the in-memory demo devices (offline-runnable)
  utControllers: string[]; // controller ingresses to enable: control4 | urc | josh
}

function envStr(key: string, fallback: string): string {
  const v = process.env[key];
  return v && v.length > 0 ? v : fallback;
}

function envInt(key: string, fallback: number): number {
  const v = process.env[key];
  if (!v) return fallback;
  const n = Number.parseInt(v, 10);
  return Number.isFinite(n) ? n : fallback;
}

function envBool(key: string, fallback: boolean): boolean {
  const v = process.env[key];
  if (v === undefined) return fallback;
  return /^(1|true|yes|on)$/i.test(v);
}

function envList(key: string, fallback: string[]): string[] {
  const v = process.env[key];
  if (v === undefined) return fallback;
  return v
    .split(",")
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
}

export function loadConfig(): BridgeConfig {
  return {
    roseHost: envStr("ROSE_HOST", "192.168.1.50"),
    rosePort: envInt("ROSE_PORT", 9283),
    roseDiscovery: envBool("ROSE_DISCOVERY", false),
    roseFirmwarePin: envStr("ROSE_FIRMWARE_PIN", "5.9.02"),
    bridgeHost: envStr("BRIDGE_HOST", "0.0.0.0"),
    bridgePort: envInt("BRIDGE_PORT", 8088),
    pollIntervalMs: envInt("POLL_INTERVAL_MS", 1000),
    utEnabled: envBool("UT_ENABLED", true),
    utRoseEnabled: envBool("UT_ROSE_ENABLED", true),
    utMockDemo: envBool("UT_MOCK_DEMO", true),
    utControllers: envList("UT_CONTROLLERS", ["control4", "urc", "josh"]),
  };
}
