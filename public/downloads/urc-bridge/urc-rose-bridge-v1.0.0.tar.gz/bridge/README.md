# urc-rose-bridge

A software bridge between **URC Total Control** and the **Hi-Fi Rose RS520** network streamer/integrated amplifier. Phase-3-ready surface for **Josh AI** voice control.

See `URC_RS520_JoshAI_Implementation_Plan.docx` for the full architecture and phased plan. This README covers running and operating the code.

---

## What this is

- **Phase 0 probe** (`src/probe.ts`) — scans the LAN for an RS520, hits every endpoint the bridge relies on, and writes a JSON report. Use this once per Rose firmware update to confirm nothing has shifted.
- **Phase 1 bridge service** (`src/bridge.ts`) — a small Fastify HTTP service that exposes a **stable** `/v1/*` contract. URC's custom IP driver hits this surface; the bridge translates to the reverse-engineered Rose API on port 9283. When Rose breaks the API in a firmware update, you patch the bridge — the URC project never changes.

The bridge contract — same shape Josh AI will hit in Phase 4 — is documented in `src/api.ts` and summarized below.

---

## Quick start

### 1. First-time discovery probe

```bash
npm install
npm run probe                    # scans local subnet, READ-only
# or, if you already know the IP:
npm run probe -- --host 192.168.1.50
# to exercise WRITE endpoints (briefly cycles power and source — be ready):
npm run probe -- --host 192.168.1.50 --write
```

Output: `probe-report-<timestamp>.json` with every endpoint, latency, and full response. Commit this file alongside the working bridge as evidence the Rose firmware build is compatible.

### 2. Run the bridge in development

```bash
cp .env.example .env             # edit ROSE_HOST to your Rose's IP
npm run dev                      # tsx watch mode
```

Then in another shell:

```bash
curl http://127.0.0.1:8088/v1/health
curl http://127.0.0.1:8088/v1/state
curl -X POST -H 'content-type: application/json' -d '{"state":"on"}' http://127.0.0.1:8088/v1/power
curl -X POST -H 'content-type: application/json' -d '{"input":"OPTICAL"}' http://127.0.0.1:8088/v1/source
curl -X POST -H 'content-type: application/json' -d '{"level":35}' http://127.0.0.1:8088/v1/volume
curl -X POST -H 'content-type: application/json' -d '{"delta":-2}' http://127.0.0.1:8088/v1/volume
```

### 3. Run as a container (recommended for production)

```bash
docker compose up --build
# logs:
docker compose logs -f bridge
```

The compose file uses `network_mode: host` so the bridge can both reach the Rose by IP and run the optional `ROSE_DISCOVERY=true` subnet scan.

---

## Bridge contract (`/v1/*`)

| Method | Path | Body | Notes |
|---|---|---|---|
| `GET`  | `/v1/health` | — | 200 if Rose is currently reachable, 503 otherwise. Surfaces `consecutiveFailures` and the firmware pin. |
| `GET`  | `/v1/state` | — | `{power, source, volume, playing, ageMs}`. Served from the poller's cache. |
| `POST` | `/v1/power` | `{state: "on"\|"off"\|"toggle"}` | Toggle reads cached state to decide. |
| `POST` | `/v1/source` | `{input: "LINE_IN"\|"OPTICAL"\|"EARC"\|"USB"\|"AES_EBU"}` | |
| `POST` | `/v1/volume` | `{level: 0..100}` **or** `{delta: ±n}` | Delta requires a known current volume; returns 409 if cache empty. |
| `POST` | `/v1/transport` | `{cmd: "play"\|"pause"\|...}` | **501 Not Implemented** — Phase 2. |

All responses are JSON. Non-2xx responses always include `{ok: false, error: ...}`.

---

## Configuration

All config is environment variables (see `.env.example` for defaults).

| Var | Default | Purpose |
|---|---|---|
| `ROSE_HOST` | `192.168.1.50` | RS520 IP. Use a DHCP reservation. |
| `ROSE_PORT` | `9283` | RS520 control port. |
| `ROSE_DISCOVERY` | `false` | If `true`, scan the LAN at startup and override `ROSE_HOST`. |
| `ROSE_FIRMWARE_PIN` | `5.9.02` | Surfaced in `/v1/health` so you can detect drift after a Rose firmware update. |
| `BRIDGE_HOST` | `0.0.0.0` | Listen address. |
| `BRIDGE_PORT` | `8088` | Listen port. URC driver targets this. |
| `POLL_INTERVAL_MS` | `1000` | How often the poller refreshes the Rose state cache. |
| `LOG_LEVEL` | `info` | `error` \| `warn` \| `info` \| `debug` |

---

## How the Rose protocol works (and why this layer exists)

Hi-Fi Rose has not published an official API. The endpoints used here were captured from packet inspection of the Rose Connect PC app and validated against the community Home Assistant integration on firmware **5.9.02**.

| Action | Endpoint | Body |
|---|---|---|
| Power on/off | `POST /remote_bar_order` | `{"barControl":"remote_bar_order_sleep_on_off","value":"1"\|"-1"}` |
| Set volume | `POST /volume` | `{"volumeType":"volume_set","volumeValue":0..100}` |
| Select input | `POST /input.mode.set` | `{"funcMode":1..5}` |
| Read state | `POST /get_current_state` | `{}` |

`funcMode`: 1=LINE IN, 2=OPTICAL, 3=eARC, 4=USB, 5=AES/EBU.

**These shapes have changed between Rose firmware releases.** That is the entire reason the bridge exists. When Rose ships a new build:

1. Run `npm run probe` on the target Rose.
2. Diff the new probe report against the committed baseline.
3. Patch `src/rose-client.ts` if endpoints moved.
4. Bump `ROSE_FIRMWARE_PIN` in `.env`.
5. Redeploy the bridge container. **The URC driver and Josh integration touch nothing.**

---

## Universal Translator (`/v2`)

The original bridge is a **1:1** translator: URC → (stable contract) → Rose. The
universal translator generalizes that into an **N-way** translator across
Control4, URC, and Josh AI, so a device that only speaks one ecosystem can be
driven from any of the others.

It is hub-and-spoke. Every ecosystem translates **to and from one neutral
vocabulary** (the "canonical model") in the middle, instead of writing a
converter for every pair. Adapters are the only code that knows a vendor's
protocol; everything else speaks canonical types.

```
 Control4 ─┐                                   ┌─ Control4 devices
      URC ─┤  controllers   ┌───────────┐  device│   URC devices
  Josh AI ─┤ ─ translate ─► │ canonical │ ─ apply├─ Josh devices
           │   inbound      │   router  │  command│   Hi-Fi Rose (LIVE)
           └─ /v2/ingress   └───────────┘         └─ mock demo devices
```

**Bridge contract (`/v2/*`)**

| Method | Path | Purpose |
|---|---|---|
| `GET`  | `/v2/entities` | Every device the bridge knows, any vendor. Filter `?ecosystem=&type=&room=`. |
| `GET`  | `/v2/entities/:id/state` | Normalized state (two-way feedback). `?fresh=1` forces a read. |
| `POST` | `/v2/command` | Issue a canonical command: `{entityId, capability, action, args}`. |
| `POST` | `/v2/ingress/:ecosystem` | Submit a **native** payload (Josh utterance, URC function, C4 verb); the adapter translates it to canonical, then dispatches. |
| `GET`  | `/v2/entities/:id/render/:ecosystem` | Canonical state rendered into a vendor's native feedback shape. |
| `GET`  | `/v2/events` | SSE stream of state changes. |

**Capabilities** (what a device can do): `power`, `volume`, `source`,
`transport`, `brightness`, `color`, `climate`, `lock`, `position`, `activate`.
The router refuses any command for a capability an entity does not advertise.

**Example — a Josh voice intent drives a Control4-only light:**

```bash
# Josh says: "turn on the living room lights"
curl -X POST http://127.0.0.1:8088/v2/ingress/josh \
  -H 'content-type: application/json' \
  -d '{"utterance":"turn on the living room lights"}'
# → translated to canonical power.set{on} → dispatched to control4:light:living-room-lights
```

**Adapter reality (honest):** none of the three platforms ships a fully open
public API. The Rose adapter is **live** (wraps the existing `RoseClient`). The
Control4 / URC / Josh adapters implement the publicly-known protocol shapes
(C4 Director, URC IP-driver functions, Josh intents) and stay **inert** for
device-hosting until real credentials are supplied — until then their devices
are stood up by the in-memory `MockAdapter` so the whole system runs offline.

| Ecosystem | Controller side (issues commands) | Device side (owns devices) |
|---|---|---|
| **Rose** | — | **live** (RS520 via `RoseClient`) |
| **Control4** | C4 verbs / canonical relay → canonical | Director `GET_DEVICES`/`SEND_COMMAND` — needs controller token |
| **URC** | IP-driver functions → canonical (+ parse-data render) | accessory API — dealer-gated |
| **Josh AI** | NL utterance **and** structured intent → canonical | Nimble DevSuite — partnership-gated |
| **Mock** | — | in-memory demo devices (offline-runnable) |

---

## Project layout

```
.
├── URC_RS520_JoshAI_Implementation_Plan.docx   ← the architecture / phased plan
├── package.json
├── tsconfig.json
├── Dockerfile
├── docker-compose.yml
├── .env.example
└── src/
    ├── bridge.ts          ← service entrypoint (starts router + /v1 + /v2)
    ├── probe.ts           ← Phase 0 discovery CLI
    ├── rose-client.ts     ← typed wrapper around the Rose HTTP API
    ├── rose-discover.ts   ← /24 subnet scanner
    ├── api.ts             ← legacy Rose-only /v1 routes (superseded by the shim)
    ├── poller.ts          ← legacy background state cache
    ├── config.ts          ← env loading
    ├── logger.ts          ← minimal level-gated logger
    └── universal/         ← the universal translator
        ├── model.ts       ← canonical entities, capabilities, commands, state
        ├── mappings.ts    ← native ↔ canonical vocabulary tables
        ├── adapter.ts     ← EcosystemAdapter interface (controller + device roles)
        ├── registry.ts    ← entity id → owning adapter
        ├── router.ts      ← dispatch + state-sync hub (the "translator")
        ├── translator.ts  ← assemble router + adapters from config
        ├── api.ts         ← Fastify routes for /v2/*
        ├── v1-shim.ts     ← original /v1 Rose contract, now router-backed
        └── adapters/
            ├── rose.ts       ← LIVE (wraps RoseClient)
            ├── control4.ts   ← Director device-host + programming controller
            ├── urc.ts        ← IP-driver controller + device scaffold
            ├── josh.ts       ← NL/intent controller + device scaffold
            └── mock.ts       ← in-memory devices for offline end-to-end
```

---

## Operations runbook

**Bridge cannot reach Rose.** `/v1/health` returns 503 with `consecutiveFailures > 0`. Check:
1. `ping <ROSE_HOST>` — network reachable?
2. Rose powered on (not in deep sleep)?
3. Static DHCP reservation still in effect?
4. Bridge and Rose on the same VLAN?

**URC driver works, then suddenly does not.** A Rose firmware update is the prime suspect. Run the probe; diff the report.

**Volume slider in URC drifts from reality.** Expected behavior. The Rose telemetry endpoint returns `volume: 0` in certain states; the poller suppresses zero-volume updates and the bridge holds the last-known-good. Treat URC as the authority.

**Restart the bridge.**
```bash
docker compose restart bridge
# or systemd-style:
systemctl restart urc-rose-bridge
```

**Roll back to a known-good build.** Container images are tagged per Rose firmware. Stop the running container, pin to the prior image tag, restart.

**Total Rose API failure (cannot turn off).** Use the iTach IP2IR fallback noted in the implementation plan §6 Phase 3.

---

## What is NOT here yet

- **URC Accelerator 3 driver** — produced once a dealer-cert workstation is available. Plan §6 Phase 1. (The bridge-side URC controller translation and parse-data render are implemented in `universal/adapters/urc.ts`.)
- **Rose transport endpoints** (`/v1/transport`) — Rose's streaming-mode transport API has not been captured. Plan §6 Phase 2. The canonical `transport` capability exists for other devices.
- **Live device-hosting credentials** — the Control4 (`Control4Director`), URC (`UrcClient`), and Josh (`JoshClient`) device hosts are written to shape but inert until a controller token / dealer access / Nimble DevSuite partnership is supplied. Offline, the `MockAdapter` stands in. The Josh **controller** side (utterance + structured intent → canonical) is fully implemented.

---

## Verifying a fresh checkout

```bash
npm install
npm run build         # tsc must exit 0
ROSE_HOST=10.255.255.1 BRIDGE_PORT=18088 LOG_LEVEL=warn node dist/bridge.js &
sleep 1
curl -s http://127.0.0.1:18088/   # should return service banner + route list
kill %1
```

If those four steps work, the bridge is healthy. The validation harness above was used to confirm this build.
